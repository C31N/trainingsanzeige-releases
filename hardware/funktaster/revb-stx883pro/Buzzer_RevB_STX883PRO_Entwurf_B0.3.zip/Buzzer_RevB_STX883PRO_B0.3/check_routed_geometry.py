#!/usr/bin/env python3
"""Independent geometry preflight approximate; NOT KiCad DRC and not RF approval."""
import re,json,math
from shapely.geometry import LineString,Point,box
from shapely.strtree import STRtree
from pathlib import Path
root=Path(__file__).resolve().parent
pcb=(root/'kicad/buzzer-revb-stx883pro-ROUTED-EXPERIMENT.kicad_pcb').read_text()
D=json.loads((root/'design.json').read_text())
netids={i+1:n for i,n in enumerate(D['nets'])}
segments=[];vias=[]
for m in re.finditer(r'\(segment \(start ([-\d.]+) ([-\d.]+)\)\(end ([-\d.]+) ([-\d.]+)\)\(width ([\d.]+)\)\(layer "?(F.Cu|B.Cu)"?\)\(net (\d+)\)',pcb):
 x,y,x2,y2,w,layer,net=m.groups();segments.append((netids[int(net)],layer,LineString([(float(x),float(y)),(float(x2),float(y2))]).buffer(float(w)/2)))
for m in re.finditer(r'\(via \(at ([-\d.]+) ([-\d.]+)\)\(size ([\d.]+)\)\(drill ([\d.]+)\).*?\(net (\d+)\)',pcb):
 x,y,size,dr,net=m.groups();vias.append((netids[int(net)],Point(float(x),float(y)).buffer(float(size)/2)))
print('tracks',len(segments),'vias',len(vias))
# compute track-track clearance pair using STRtree per layer
for l in ['F.Cu','B.Cu']:
 layer=[(net,p) for net,ly,p in segments if ly==l]+[(net,p) for net,p in vias]
 shapes=[p for n,p in layer];tree=STRtree(shapes); bad=[]
 for i,(net,p) in enumerate(layer):
  for j in tree.query(p.buffer(.2)):
   j=int(j)
   if j<=i:continue
   other,geo=layer[j]
   if net!=other and p.distance(geo)<0.2-1e-6:
    bad.append((net,other,round(p.distance(geo),3)))
 print(l,'short-clearances',len(bad),bad[:25])
