#!/usr/bin/env python3
"""RevB experiment #2: clearance-aware 0.25-mm grid two-layer router.

NO FABRICATION RELEASE. This is a computer-aided candidate only. Independent
KiCad ERC/DRC, RF trace geometry, module landpattern and hardware qualification
are mandatory. No copper files emitted here.
"""
from __future__ import annotations
import json, re, uuid, math, heapq
from pathlib import Path
from collections import defaultdict
import numpy as np
from shapely.geometry import box, Point, LineString
from shapely import contains_xy
from shapely.ops import unary_union
R=Path(__file__).resolve().parent
D=json.loads((R/'design.json').read_text()); LIB=R/'kicad/WFD-RevB.pretty'; B=R/'kicad/buzzer-revb-stx883pro-PLACEMENT-ONLY.kicad_pcb'
G=.25; W=30; H=70; NX=round(W/G)+1; NY=round(H/G)+1
NETS=D['nets'];NID={n:i+1 for i,n in enumerate(NETS)}
LAYER={"F.Cu":0,"B.Cu":1}; ALIAS={'HEADER_1x02':'PinHeader_1x02_P2.54mm_Vertical','HEADER_1x03':'PinHeader_1x03_P2.54mm_Vertical'}
TRACE_WIDTH=0.25;DRC_CLEAR=.20; VIA_DIAM=.75;VIA_DRILL=.35
PADS=[];T=defaultdict(list)
def block(text,st):
 dep=0;quot=False;esc=False
 for i in range(st,len(text)):
  c=text[i]
  if quot:
   if esc:esc=False
   elif c=='\\':esc=True
   elif c=='"':quot=False
  elif c=='"':quot=True
  elif c=='(':dep+=1
  elif c==')':
   dep-=1
   if dep==0:return text[st:i+1]
 raise ValueError('no end')
for part in D['parts']:
 f=ALIAS.get(part['fp'],part['fp']);s=(LIB/(f+'.kicad_mod')).read_text();st=0
 while True:
  st=s.find('(pad ',st)
  if st<0:break
  p=block(s,st);st+=len(p)
  pin=re.search(r'^\(pad\s+"([^"]*)"',p);at=re.search(r'\(at\s+([-\d.]+)\s+([-\d.]+)',p);dims=re.search(r'\(size\s+([-\d.]+)\s+([-\d.]+)',p)
  if not pin or not at or not dims:continue
  name=pin.group(1);x=part['xy'][0]+float(at.group(1));y=part['xy'][1]+float(at.group(2));sx,sy=map(float,dims.groups());net=part['pins'].get(name) or '#FLOAT';through='thru_hole' in p;npth='np_thru_hole' in p
  g=Point(x,y).buffer(sx/2,resolution=32) if ' circle ' in p else box(x-sx/2,y-sy/2,x+sx/2,y+sy/2)
  v=dict(ref=part['ref'],pin=name,x=x,y=y,net=net,geom=g,through=through,npth=npth)
  PADS.append(v)
  if net!='#FLOAT':T[net].append(v)
print('pad count',len(PADS),'nets',len(T),flush=True)
XS,YS=np.meshgrid(np.arange(NX)*G,np.arange(NY)*G,indexing='ij')
coords=np.stack([XS.ravel(),YS.ravel()],axis=1)
# Pad ownership used for point-route and center-via keepouts.
PAD_MASKS={}; VIA_PAD_MASKS={}
for layer in range(2):
 op=defaultdict(list)
 for pad in PADS:
  if layer==1 and not pad['through']:continue
  geom=pad['geom']
  if pad['npth']:
   op['#HOLE'].append(geom)
  else:op[pad['net']].append(geom)
 PAD_MASKS[layer]={};VIA_PAD_MASKS[layer]={}
 for net, geoms in op.items():
  poly=unary_union(geoms)
  # Track center avoids other pad copper by 0.125+0.20+0.04 reserve.
  PAD_MASKS[layer][net]=contains_xy(poly.buffer(TRACE_WIDTH/2+DRC_CLEAR+.04),XS,YS)
  # Through via center avoids any other-net copper by 0.375+0.20+.05.
  VIA_PAD_MASKS[layer][net]=contains_xy(poly.buffer(VIA_DIAM/2+DRC_CLEAR+.05),XS,YS)

# Ownership dynamic layer maps netID to tracks, expanded by geometric clearance.
TRACK_MASKS={0:defaultdict(lambda: np.zeros((NX,NY),dtype=bool)),1:defaultdict(lambda:np.zeros((NX,NY),dtype=bool))}
VIA_MASKS={0:defaultdict(lambda:np.zeros((NX,NY),dtype=bool)),1:defaultdict(lambda:np.zeros((NX,NY),dtype=bool))}
# performance: produce a combined occupied mask per layer for other nets; building when entering a net
PADDING=TRACE_WIDTH+DRC_CLEAR+.05
OFFSETS=[(dx,dy) for dx in range(-3,4) for dy in range(-3,4) if math.hypot(dx,dy)*G <= PADDING+.01]
# Via is fatter. Tracking via vs tracks needs radius .375+.125+.2 =.7.
VIA_OFFSETS=[(dx,dy) for dx in range(-4,5) for dy in range(-4,5) if math.hypot(dx,dy)*G <= VIA_DIAM/2+TRACE_WIDTH/2+DRC_CLEAR+.04]
VIA_VIA_OFFSETS=[(dx,dy) for dx in range(-6,7) for dy in range(-6,7) if math.hypot(dx,dy)*G <= VIA_DIAM+DRC_CLEAR+.04]
occupied={0:defaultdict(set),1:defaultdict(set)}

def reserve(l,i,j,net,via=False):
 for dx,dy in (VIA_OFFSETS if via else OFFSETS):
  a,b=i+dx,j+dy
  if 0<=a<NX and 0<=b<NY:occupied[l][(a,b)].add(net)

# Always reserve the U2.2 ground escape BEFORE any signal routing. The first
# router trapped this pin behind BAT and BUTTON traces; an isolated GND
# island is unacceptable even if a ground zone exists elsewhere on the PCB.
GND_SOURCE=(4.8625,52.6)
GND_VIA=(3.5,52.5)
for i in range(round(GND_VIA[0]/G),round(GND_SOURCE[0]/G)+1):
    reserve(0,i,round(GND_VIA[1]/G),'GND')
for ll in (0,1):reserve(ll,round(GND_VIA[0]/G),round(GND_VIA[1]/G),'GND',via=True)


def static_forbidden(net,l,for_via):
 op=VIA_PAD_MASKS[l] if for_via else PAD_MASKS[l]
 blocked=np.zeros((NX,NY),dtype=bool)
 for other,m in op.items():
  if other!=net:blocked |= m
 return blocked

def build_bans(net):
 no=[static_forbidden(net,l,False) for l in range(2)]
 via=[static_forbidden(net,l,True) for l in range(2)]
 for l in (0,1):
  for (i,j),owners in occupied[l].items():
   if owners-{net}:no[l][i,j]=True
  # Via centers require expanded clearance beyond centerline occupancy; dynamic from actual copper generated below.
 return no,via

def idx_pad(p):
 # Choose grid node strictly inside pad or near center. For PTH allow either layer.
 ii=int(round(p['x']/G));jj=int(round(p['y']/G))
 return (max(0,min(NX-1,ii)),max(0,min(NY-1,jj)))

def starts(p,no):
 ii,jj=idx_pad(p);arr=[]
 for dx in range(-4,5):
  for dy in range(-4,5):
   i,j=ii+dx,jj+dy
   if i<=1 or i>=NX-2 or j<=1 or j>=NY-2:continue
   if not p['geom'].buffer(.12).contains(Point(i*G,j*G)):continue
   for l in ([0,1] if p['through'] else [0]):
    if not no[l][i,j]:arr.append((math.hypot(i*G-p['x'],j*G-p['y']),l,i,j))
 return [tuple(x[1:]) for x in sorted(arr)[:12]]

def viaok(net,l,i,j,via_bans):
 if via_bans[0][i,j] or via_bans[1][i,j]:return False
 for ll in (0,1):
  for di,dj in VIA_OFFSETS:
   ii,jj=i+di,j+dj
   if (ii,jj) in occupied[ll] and occupied[ll][(ii,jj)]-{net}:return False
 return True
STEPS=[(1,0,1),(0,1,1),(-1,0,1),(0,-1,1),(1,1,1.41421356),(1,-1,1.41421356),(-1,1,1.41421356),(-1,-1,1.41421356)]

def astar(net,starts,target,no,via_bans,limit=500000):
 target=set(target)
 if not starts or not target:return None
 minxy=np.array([(i,j) for l,i,j in target]); minx,maxx=minxy[:,0].min(),minxy[:,0].max();miny,maxy=minxy[:,1].min(),minxy[:,1].max()
 def heur(s):
  l,i,j=s
  return math.hypot(max(minx-i,0,i-maxx),max(miny-j,0,j-maxy))+0 # cheap admissible
 heap=[];g={};parent={}
 for st in starts:
  if no[st[0]][st[1],st[2]]:continue
  g[st]=0;heapq.heappush(heap,(heur(st),0,st))
 steps=0
 while heap and steps<limit:
  f,d,u=heapq.heappop(heap);steps+=1
  if d>g.get(u,1e30)+1e-8:continue
  if u in target:
   ans=[u]
   while u in parent:u=parent[u];ans.append(u)
   ans.reverse();return ans,steps
  l,i,j=u
  for dx,dy,wt in STEPS:
   ni,nj=i+dx,j+dy
   if ni<=1 or ni>=NX-2 or nj<=1 or nj>=NY-2:continue
   if no[l][ni,nj]:continue
   if dx and dy and (no[l][i+dx,j] or no[l][i,j+dy]):continue
   v=(l,ni,nj);cost=d+wt
   if cost+1e-8<g.get(v,1e30):g[v]=cost;parent[v]=u;heapq.heappush(heap,(cost+heur(v),cost,v))
  if viaok(net,l,i,j,via_bans):
   v=(1-l,i,j);cost=d+13
   if cost+1e-8<g.get(v,1e30):g[v]=cost;parent[v]=u;heapq.heappush(heap,(cost+heur(v),cost,v))
 return None,steps

def simplify(chain):
 if len(chain)<=2:return chain
 out=[chain[0]]
 for b,c in zip(chain[1:-1],chain[2:]):
  a=out[-1]
  if a[0]==b[0]==c[0] and (b[1]-a[1])*(c[2]-b[2])==(b[2]-a[2])*(c[1]-b[1]):continue
  out.append(b)
 return out+[chain[-1]]

routes=[]; stats={};failed=[];vias=[]
priority=['ANT','RF_DATA','MCU_DATA','BUTTON','PGATE','DGATE','BASE_INTERLOCK','SINK_GATE','BASE_POWER','SCK','MISO','MOSI','RESET','POWER','DISCHARGE','BUTTON_RAW','SWVIN','UPDI','BAT','TX3V3','3V3','BAT_FUSED','DRAIN_DISCHARGE']
allnets=sorted([n for n in T if n!='GND' and n!='#FLOAT'],key=lambda n:(priority.index(n) if n in priority else 999,-len(T[n])))
for net in allnets:
 ps=T[net];
 if len(ps)<2:continue
 connected=[ps[0]];pending=ps[1:];trunk=[];total_expansions=0
 while pending:
  no,via_bans=build_bans(net)
  # sort by Cartesian minimum distance to any other pad (avoids long initial detours)
  pending.sort(key=lambda p:min(math.hypot(p['x']-q['x'],p['y']-q['y']) for q in connected))
  accepted=False
  for p in list(pending):
   starts_p=starts(p,no)
   goals=[]
   for q in connected:
    goals.extend(starts(q,no))
   # include existing routed path as targets for easier fanout
   goals.extend([q for q in trunk if 1<q[1]<NX-2 and 1<q[2]<NY-2 and not no[q[0]][q[1],q[2]]])
   res=astar(net,starts_p,goals,no,via_bans)
   if res and res[0]:
    chain,exp=res;total_expansions+=exp
    # reserve copper around every node. Enforce source/target exact pad connection by initial grid node on-pad.
    for l,i,j in chain:reserve(l,i,j,net)
    for a,b in zip(chain,chain[1:]):
     if a[0]!=b[0]:
      for l in (0,1):reserve(l,a[1],a[2],net,via=True)
    routes.append((net,p,chain));trunk.extend(chain);connected.append(p);pending.remove(p);accepted=True
    break
  if not accepted:break
 stats[net]={'connected':len(connected),'total':len(ps),'paths':len(connected)-1,'expanded':total_expansions}
 print(net,stats[net],flush=True)
 if pending:failed.append((net,[(p['ref'],p['pin']) for p in pending]))
# For now ground relies on both-layer copper zone (F.Cu + B.Cu), with via stitching to be validated by KiCad.
# In a RevB prototype, DRC must demonstrate every pin connected; this script does not claim it.
S=B.read_text();assert S.strip().endswith(')')
def UUID(key):return str(uuid.uuid5(uuid.NAMESPACE_URL,'WFD-REV-B-R2:'+str(key)))
lines=[];tracecount=0;viacount=0
# U2 GND dogbone; signal router was blocked from crossing this reserve.
lines.append(f'(segment (start {GND_SOURCE[0]:.4f} {GND_SOURCE[1]:.4f}) (end {GND_VIA[0]:.4f} {GND_VIA[1]:.4f}) (width {TRACE_WIDTH}) (layer F.Cu) (net {NID["GND"]}) (uuid "{UUID("U2-GND-trace")}"))')
lines.append(f'(via (at {GND_VIA[0]:.4f} {GND_VIA[1]:.4f}) (size {VIA_DIAM}) (drill {VIA_DRILL}) (layers "F.Cu" "B.Cu") (net {NID["GND"]}) (uuid "{UUID("U2-GND-via")}"))')

for k,(net,p,chain) in enumerate(routes):
 simple=simplify(chain)
 # Attach exact pad center to path's starting on-pad grid vertex.
 first=simple[0];x,y=first[1]*G,first[2]*G
 if (x,y)!=(p['x'],p['y']):
  lines.append(f'(segment (start {p["x"]:.4f} {p["y"]:.4f}) (end {x:.4f} {y:.4f}) (width {TRACE_WIDTH}) (layer {"F.Cu" if first[0]==0 else "B.Cu"}) (net {NID[net]}) (uuid "{UUID((k,"src"))}"))');tracecount+=1
 for j,(a,b) in enumerate(zip(simple,simple[1:])):
  if a[0]!=b[0]:
   lines.append(f'(via (at {a[1]*G:.4f} {a[2]*G:.4f}) (size {VIA_DIAM}) (drill {VIA_DRILL}) (layers "F.Cu" "B.Cu") (net {NID[net]}) (uuid "{UUID((k,j,"via"))}"))');viacount+=1
  else:
   lines.append(f'(segment (start {a[1]*G:.4f} {a[2]*G:.4f}) (end {b[1]*G:.4f} {b[2]*G:.4f}) (width {TRACE_WIDTH}) (layer {"F.Cu" if a[0]==0 else "B.Cu"}) (net {NID[net]}) (uuid "{UUID((k,j,"seg"))}"))');tracecount+=1
# Ground zones, no fake GND fanouts; filled via KiCad only.
for lname in ('F.Cu','B.Cu'):
 lines.append(f'''(zone (net {NID['GND']}) (net_name "GND") (layer "{lname}") (uuid "{UUID(('zone',lname))}")
 (hatch edge 0.5) (priority 1) (connect_pads (type solid) (clearance 0.3)) (min_thickness 0.25) (fill yes (thermal_gap 0.3)(thermal_bridge_width 0.35))
 (polygon (pts (xy 0.35 0.35) (xy 29.65 0.35) (xy 29.65 69.65) (xy 0.35 69.65))))''')
out=R/'kicad/buzzer-revb-stx883pro-ROUTED-V2-EXPERIMENT.kicad_pcb';out.write_text(S.rstrip()[:-1]+'\n'+'\n'.join(lines)+'\n)')
result={'revision':'B0.2_ROUTING_EXPERIMENT','release':False,'grid_mm':G,'track_width_mm':TRACE_WIDTH,'clearance_target_mm':DRC_CLEAR,'via_diameter_mm':VIA_DIAM,'trace_segments':tracecount,'vias':viacount,'all_nets':stats,'remaining_net_chains':failed,'ground_copper_zones':'F.Cu+B.Cu unfilled, connectivity unverified','native_drc':'NOT RUN','module_landpattern':'NOT VERIFIED'}
(R/'validation/router_v2_report.json').write_text(json.dumps(result,indent=2))
print('CANDIDATE',tracecount,'segments',viacount,'vias',len(failed),'failed',failed,flush=True)
