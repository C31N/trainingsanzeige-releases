#!/usr/bin/env python3
import json,svgwrite,cairosvg,re
from pathlib import Path
R=Path(__file__).resolve().parent
D=json.loads((R/'design.json').read_text());P=D['parts'];out=R/'docs';out.mkdir(exist_ok=True)
W,H=30,70;S=23;OX=135;OY=95
sv=svgwrite.Drawing(str(out/'Layout_Uebersicht.svg'),size=('1440px','1750px'),viewBox='0 0 1440 1750')
sv.add(sv.rect(insert=(0,0),size=(1440,1750),fill='#0b1722'))
sv.add(sv.text('WASSERFREUNDE DALUM  /  BUZZER REV B0.1',insert=(70,55),fill='#eaf5ff',font_family='DejaVu Sans',font_size=30,font_weight='bold'))
sv.add(sv.text('STX883PRO-433MHz  ·  30 × 70 mm  ·  platzierter CAD-Entwurf',insert=(70,85),fill='#8bb7c7',font_family='DejaVu Sans',font_size=20))
sv.add(sv.rect(insert=(OX,OY),size=(W*S,H*S),fill='#00674b',stroke='#85c3ab',stroke_width=4,rx=12))
# coarse board subdivisions, no routed conductor claims
for y in [22,39,56]:
 sv.add(sv.line(start=(OX+8,OY+y*S),end=(OX+W*S-8,OY+y*S),stroke='#c8ddbe',stroke_width=1.2,stroke_dasharray='5 5',opacity=.38))
for p in P:
 x,y=p['xy'];cx=OX+x*S;cy=OY+y*S;ref=p['ref'];kind=p['kind']
 if ref=='U5': w,h=14.12*S,14.67*S; fill='#173552';stroke='#43c6f2';txt='STX883PRO\n433.92 MHz'
 elif ref in ['U1','U4']:w,h=8*S,6.7*S;fill='#163a2f';stroke='#d9e4bd';txt=ref+'\n'+ ('ATtiny402' if ref=='U1' else 'ATtiny13A')
 elif ref in ['U2','U3']:w,h=3.8*S,4.4*S;fill='#224f34';stroke='#b9d1a9';txt=ref
 elif ref in ['J1','J2','J4','J5','J3']:w,h=(2.8*S, (7.7 if ref in ['J4','J5'] else 5.8 if ref in ['J1','J2'] else 2.8)*S);fill='#edbf65';stroke='#ffefbd';txt=ref
 elif ref.startswith('H'):w,h=2.6*S,2.6*S;fill='#073b2c';stroke='#ddedbe';txt=''
 elif ref.startswith('Q'):w,h=3.5*S,3.3*S;fill='#234b44';stroke='#e7f2cf';txt=ref
 elif ref.startswith('D'):w,h=(5.5 if ref=='D2' else 3.6)*S,2.7*S;fill='#234b44';stroke='#e7f2cf';txt=ref
 elif ref=='R11':w,h=6.5*S,3.2*S;fill='#234b44';stroke='#d7efcc';txt=ref
 else:w,h=2.5*S,1.65*S;fill='#325b49';stroke='#d5e3cc';txt=ref
 if kind=='mechanical':
  sv.add(sv.circle(center=(cx,cy),r=w/2,fill=fill,stroke=stroke,stroke_width=2));sv.add(sv.circle(center=(cx,cy),r=w/4,fill='#0b1722'))
 else:
  sv.add(sv.rect(insert=(cx-w/2,cy-h/2),size=(w,h),fill=fill,stroke=stroke,stroke_width=2.1,rx=2.5))
  if ref=='U5':
   sv.add(sv.text('STX883PRO',insert=(cx,cy-14),text_anchor='middle',fill='#b5efff',font_family='DejaVu Sans',font_size=20,font_weight='bold'))
   sv.add(sv.text('433 MHz',insert=(cx,cy+16),text_anchor='middle',fill='#b5efff',font_family='DejaVu Sans',font_size=18))
  elif ref.startswith('J'): sv.add(sv.text(ref,insert=(cx,cy+7),text_anchor='middle',fill='#15212b',font_size=18,font_weight='bold',font_family='DejaVu Sans'))
  elif ref in ['U1','U4']: sv.add(sv.text(ref,insert=(cx,cy-7),text_anchor='middle',fill='#e8f5e9',font_family='DejaVu Sans',font_size=18,font_weight='bold'))
  else:sv.add(sv.text(ref,insert=(cx,cy+5),text_anchor='middle',fill='#e7f2df',font_family='DejaVu Sans',font_size=13))
# annotations right of board
sx=OX+W*S+50
anns=[('01  FUNKTEIL','U5 STX883PRO + J3 Antenne'),('02  DIAMEX V2','U4 ATtiny13A / J5 ISP'),('03  3,3-V-SENDER','U3 LDO / C5–C9'),('04  IMPULSVERLÄNGERUNG','U1 ATtiny402 / Q1–Q4'),('05  9-V-VERICO','J1 Akku / D2 Schutz'),('06  ANSCHLÜSSE','J2 Schließer / J4 UPDI')]
for ix,(title,desc) in enumerate(anns):
 y=260+ix*207
 sv.add(sv.text(title,insert=(sx,y),fill='#e1edf4',font_family='DejaVu Sans',font_size=21,font_weight='bold'))
 sv.add(sv.text(desc,insert=(sx,y+29),fill='#8fb6c0',font_family='DejaVu Sans',font_size=16))
sv.add(sv.rect(insert=(0,1710),size=(1440,40),fill='#d48626'))
sv.add(sv.text('ENTWURF B0.1  –  KEINE FREIGABE FÜR JLCPCB / GERBER / BETRIEB',insert=(55,1738),fill='#0c1824',font_family='DejaVu Sans',font_size=21,font_weight='bold'))
sv.save();cairosvg.svg2png(url=str(out/'Layout_Uebersicht.svg'),write_to=str(out/'Layout_Uebersicht.png'),output_width=1440,output_height=1750)
print(out/'Layout_Uebersicht.png')
