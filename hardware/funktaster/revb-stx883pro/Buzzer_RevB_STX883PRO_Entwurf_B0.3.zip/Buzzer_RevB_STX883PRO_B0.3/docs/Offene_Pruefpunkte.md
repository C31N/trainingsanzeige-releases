# Rev B0.1 – offener Prüf- und Entwicklungsstatus

**BLOCKIERT: keine JLCPCB-Bestellung freigeben.**

## Geometrische und elektrische Fakten
- 30 x 70 mm Platzierung, 35 SMD, fünf Anschlussgruppen, zwei Montagebohrungen; die Gehäusepassung ist nicht gemessen.
- Eigenes Symbol- und Footprint-Set wurde erzeugt. Der STX883PRO-Footprint ist nur eine mechanische Annäherung, keine freigegebene Lötflächengeometrie.
- Der automatisierte Routingversuch ist **nicht** verwendbar: mindestens zwei verbliebene GND-Verbindungen (U2.2, U4.4) und in der stichprobenartigen geometrischen Überprüfung **mindestens 13 F.Cu-Kollisionen/Unterschreitungen**; tatsächlicher KiCad-DRC noch nicht ausgeführt.
- Das Platzierungs-PCB enthält **gar keine Leiterbahnen**. Beide Varianten sind für die Fertigung ungeeignet.
- Schaltplan basiert auf den V5- und Rev-A-Unterlagen; er muss vor Bestückung elektrisch und anhand der exakten MCU- und Modul-Pinbelegung verifiziert werden.

## Nächste prüfbare Schritte
1. Offizielle STX883PRO-C3001517-Lötflächen aus JLCPCB/EasyEDA mit dem Footprint 1:1 vergleichen, besonders Antennenpad 4.
2. KiCad-8-ERC/DRC ausführen, Fehler analysieren und Entflechtung manuell/mit überprüfbarem Router vollständig abschließen (unconnected=0, violation=0).
3. Antennenleitung mit Referenzmasse und Zielimpedanz 50 Ohm dimensionieren; Abstand zu 9-V-Leitungen, Schalterleitungen, Rand und Montagebohrung kontrollieren.
4. Digitale I/O: ISP/UPDI-Pinout, 3V3-Regler, Q1-Q4, Verpolung, D1, 100R-1W-Impulsentladung und sicherer Reset der TX3V3-Schiene prüfen.
5. JLCPCB-Stückliste, Bestückungsrotationen, Footprint-/Hersteller-Äquivalenz, LCSC-Stock und ggf. Panelisierung bestätigen. Nicht automatisch nicht bestätigte Bauteile ersetzen.
6. Erst **eine** reale Platine in einem Testaufbau prüfen: 9-V-VERICO-Ruhestrom, LDO-Temperatur, 1-ms-Buzzer, Impulslänge, Reset, Reichweite, 433,92 MHz, ERP und Duty Cycle; erst nach Freigabe der ersten die übrigen einsetzen.
7. Identische Hardware mit eindeutigen ATtiny13A-IDs 1–5 flashen und jede V2-ID unter Empfangskontrolle testen.

## Release-Gates
`schematic_reviewed=false; rf_footprint_verified=false; routing_completed=false; native_drc_passed=false; real_hardware_verified=false; fabrication_release=false`
