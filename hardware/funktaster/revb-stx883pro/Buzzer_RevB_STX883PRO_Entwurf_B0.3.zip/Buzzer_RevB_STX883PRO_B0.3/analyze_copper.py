#!/usr/bin/env python3
import json,re,math
from pathlib import Path
from collections import Counter,defaultdict
from shapely.geometry import LineString,Point,box
from shapely.strtree import STRtree
ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/'design.json').read_text()); netids={i+1:n for i,n in enumerate(D['nets'])}
text=(ROOT/'kicad/buzzer-revb-stx883pro-ROUTED-V3-EXPERIMENT.kicad_pcb').read_text()
def block(text,start):
 depth=0;string=False;escape=False
 for i in range(start,len(text)):
  c=text[i]
  if string:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':string=False
  elif c=='"':string=True
  elif c=='(':depth+=1
  elif c==')':
   depth-=1
   if depth==0:return text[start:i+1]
 raise RuntimeError('unclosed')
items=[]
def add(net,ly,geom,label):
 items.append((net,ly,geom,label))
for m in re.finditer(r'\(segment \(start ([-\d.]+) ([-\d.]+)\)\s*\(end ([-\d.]+) ([-\d.]+)\)\s*\(width ([\d.]+)\)\s*\(layer "?(F.Cu|B.Cu)"?\)\s*\(net (\d+)\)',text):
 x,y,x2,y2,w,layer,net=m.groups();add(netids[int(net)],layer,LineString([(float(x),float(y)),(float(x2),float(y2))]).buffer(float(w)/2),f'track:{m.start()}')
for m in re.finditer(r'\(via \(at ([-\d.]+) ([-\d.]+)\)\s*\(size ([\d.]+)\)\s*\(drill ([\d.]+)\).*?\(net (\d+)\)',text):
 x,y,size,dr,net=m.groups(); p=Point(float(x),float(y)).buffer(float(size)/2);n=netids[int(net)];add(n,'F.Cu',p,'via:'+str(m.start()));add(n,'B.Cu',p,'via:'+str(m.start()))
LIB=ROOT/'kicad/WFD-RevB.pretty';alias={'HEADER_1x02':'PinHeader_1x02_P2.54mm_Vertical','HEADER_1x03':'PinHeader_1x03_P2.54mm_Vertical'}
for part in D['parts']:
 s=(LIB/(alias.get(part['fp'],part['fp'])+'.kicad_mod')).read_text();k=0
 while True:
  k=s.find('(pad ',k)
  if k<0:break
  b=block(s,k);k+=len(b)
  nr=re.search(r'\(pad\s+"([^"]*)"',b)
  ma=re.search(r'\(at\s+([-\d.]+)\s+([-\d.]+)',b)
  sz=re.search(r'\(size\s+([-\d.]+)\s+([-\d.]+)',b)
  if not nr or not ma or not sz:continue
  pin=nr.group(1);net=part['pins'].get(pin) or '#NC';x=part['xy'][0]+float(ma.group(1));y=part['xy'][1]+float(ma.group(2));w,h=map(float,sz.groups());npth='np_thru_hole' in b;thru='thru_hole' in b
  if npth: net='#HOLE'
  if ('circle' in b) and thru:g=Point(x,y).buffer(w/2)
  else:g=box(x-w/2,y-h/2,x+w/2,y+h/2)
  add(net,'F.Cu',g,part['ref']+'.'+pin)
  if thru:add(net,'B.Cu',g,part['ref']+'.'+pin)

print('Parsed copper geometries:',len(items),'tracks',sum(x[3].startswith('track') for x in items),'pads',sum('.' in x[3] for x in items),'vias',sum(x[3].startswith('via') for x in items))
for layer in ['F.Cu','B.Cu']:
 arr=[x for x in items if x[1]==layer];geoms=[x[2] for x in arr];tree=STRtree(geoms);viol=[];d=defaultdict(list)
 for i,(net,ly,g,lab) in enumerate(arr):
  for j in tree.query(g.buffer(.2)):
   j=int(j)
   if j<=i:continue
   net2,_,g2,lab2=arr[j]
   if net!=net2 and g.distance(g2)<0.19999:
    viol.append((net,net2,round(g.distance(g2),3),lab,lab2))
    d['|'.join(sorted([net,net2]))].append((lab,lab2))
 print('\n',layer,'total copper+pad potential 0.2mm violations',len(viol),'pairs',len(d))
 for key,x in sorted(d.items(),key=lambda t:-len(t[1]))[:25]:print(key,len(x),x[:3])

# This report is only a 2D copper geometry check, not a full KiCad DRC.

