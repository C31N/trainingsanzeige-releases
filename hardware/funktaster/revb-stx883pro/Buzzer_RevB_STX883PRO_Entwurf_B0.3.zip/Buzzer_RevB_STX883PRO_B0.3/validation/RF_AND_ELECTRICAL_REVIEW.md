# Rev B0.2 — offene elektrische und HF-Freigabepunkte

Status: NICHT BESTELLFERTIG / EVALUATION BOARD ONLY.

## Funkteil und Antenne
- STX883PRO-433MHz C3001517, nach G-NiceRF 1.2–5 V, 433.92 MHz typisch, 10 dBm bei 3.3 V, Datenrate 0.1–5 kbps, Pins: 1=GND, 2=VCC, 3=DATA, 4=ANT.
- Der generierte Lötflächen-Footprint wurde nur aus der Datenblattzeichnung abgeleitet; verbindlichen JLC/EasyEDA-Landpattern-Abgleich vor der Fertigung vornehmen. Die tatsächliche Padgeometrie für automatisches Reflow-Löten ist nicht bestätigt.
- Antenne: 50-Ohm-Port. Der mit 0,25-mm-Leiterbahnen geroutete ANT-Kandidat ist **kein verifiziertes 50-Ohm-Netzwerk** auf FR4 1,6 mm. Er bleibt ungeeignet als fertiger HF-Entwurf. Alternativ sehr kurzen Antennen-Pigtail an definiertem 50-Ohm-Launch mit Massebezug planen und HF-Messung durchführen; 433-MHz-Strahlungsleistung mit finaler Antenne messen.
- 10 dBm am Modulausgang sind nicht dasselbe wie 10 mW ERP am Endgerät. Nationale Frequenznutzungsvorschriften, Duty Cycle, Oberwellen und Gehäuse/Antenne prüfen.

## Spannungen und Timer
- VERICO-9-V-Aufwärtswandler: Spannung unter Last + Unterspannung + Mindestlast/Auto-Off messen.
- Eingang J1 liegt nach externer 250-mA-Sicherung; D2 SS14 sorgt für Verpolschutz. Bei Entladewiderstand R11 100 Ohm / 1W die Kurzzeitimpulsbelastung und Hardwaresperre prüfen.
- U2 immer aktive 3,3-V-Zentrale; U3 3,3 V TX schaltet nur während der 1.000-ms-Sendefolge. TPS70933 EN-Pin nicht direkt an 9 V legen; Gehäuse/Pinout vorher kontrollieren.
- 1-ms-Kontakt, Langdruck, wiederholtes Drücken, Watchdog-Reset, Brown-out, Entladung SWVIN/TX3V3 <0,3 V und danach Neustart mit aktualisierter V2-Ereignisnummer testen.
- ISP 6polig und UPDI 3polig: Pinmarkierungen, Programmer, kein 5-V-/9-V-Rückspeisen.

## Werkzeuge / Prüfstand
- Erfolgreiche 2D-Kupferkonfliktvorprüfung: 419 Segmente, 21 Signal-Vias, 22 zusätzliche Masse-Stitch-Vias; 0 <0,2-mm-Kollisionen zwischen unterschiedlichen Netzen, **nur gerasterte Kandidatengeometrie**.
- KiCad 8 ERC/DRC inklusive gefüllter Massezonen, Footprint-Rules, Unconnected-Nets und Board-Edge-Verletzungen separat ausführen und protokollieren.
- Erst danach einen einzigen realen Prototypen bei strombegrenzter 9-V-Versorgung in Betrieb nehmen. Kein 5er-Auftrag ohne Prototyp-Abnahme.
