#!/usr/bin/env python3
"""Experimental grid autorouter of Rev B: never claims DRC or fabrication release.
Uses true pad rectangles from KiCad footprint sources, 0.5mm grid, two layers, vias,
A* between all non-ground terminals, B.Cu ground-fill zone.
"""
import json,re,heapq,math,sys,uuid,itertools
from pathlib import Path
from collections import defaultdict
from shapely.geometry import Point,box
ROOT=Path(__file__).resolve().parent;D=json.loads((ROOT/'design.json').read_text());OUT=ROOT/'kicad'
BOARD=OUT/'buzzer-revb-stx883pro-PLACEMENT-ONLY.kicad_pcb';out=OUT/'buzzer-revb-stx883pro-ROUTED-EXPERIMENT.kicad_pcb'
parts=D['parts'];width,height=30,70;G=0.5
FPALIASES={'HEADER_1x02':'PinHeader_1x02_P2.54mm_Vertical','HEADER_1x03':'PinHeader_1x03_P2.54mm_Vertical'}
lib=OUT/'WFD-RevB.pretty'

def block(text,start):
  depth=0;string=False;escape=False
  for i in range(start,len(text)):
    ch=text[i]
    if string:
      if escape:escape=False
      elif ch=='\\':escape=True
      elif ch=='"':string=False
    elif ch=='"':string=True
    elif ch=='(':depth+=1
    elif ch==')':
      depth-=1
      if depth==0:return text[start:i+1]
  raise RuntimeError('no close')

def uid(key):return str(uuid.uuid5(uuid.NAMESPACE_URL,'WFD:REV-B:ROUTE:'+str(key)))

netids={name:i+1 for i,name in enumerate(D['nets'])}
TERMS=defaultdict(list);pads=[]
for p in parts:
  fp=FPALIASES.get(p['fp'],p['fp'])
  s=(lib/f'{fp}.kicad_mod').read_text()
  ix=0
  while True:
    ix=s.find('(pad ',ix)
    if ix<0:break
    b=block(s,ix);ix+=len(b)
    nr=re.match(r'\(pad "(.*?)"',b)
    if nr is None:continue
    pin=nr.group(1)
    m=re.search(r'\(at\s+([-.\d]+)\s+([-.\d]+)',b)
    size=re.search(r'\(size\s+([-.\d]+)\s+([-.\d]+)',b)
    if not m or not size:continue
    net=p['pins'].get(pin)
    x=p['xy'][0]+float(m.group(1));y=p['xy'][1]+float(m.group(2))
    a,bsize=float(size.group(1)),float(size.group(2));t={'ref':p['ref'],'pin':pin,'net':net,'x':x,'y':y,'width':a,'height':bsize,'thru':('(thru_hole' in b or 'thru_hole' in b), 'npth':'np_thru_hole' in b}
    pads.append(t)
    if net:TERMS[net].append(t)

NX=round(width/G)+1;NY=round(height/G)+1
# grid only at x = 0.5*i, y=0.5*j
coord=lambda i,j:(i*G,j*G)
node=lambda x,y:(max(1,min(NX-2,round(x/G))),max(1,min(NY-2,round(y/G))))

# Ownership map, each cell blocked from other nets if too near pads/tracks.
OWN=[defaultdict(set),defaultdict(set)]
def ck(pt, w, h, clearance, i,j):
 x,y=coord(i,j);return abs(x-pt['x'])<=(w/2+clearance) and abs(y-pt['y'])<=(h/2+clearance)
for pt in pads:
 if pt['npth']:
  for l in range(2):
   for i in range(1,NX-1):
    for j in range(1,NY-1):
     if ck(pt,pt['width'],pt['height'],.5,i,j):OWN[l][(i,j)].add('#HOLE')
 else:
  for l in ([0,1] if pt['thru'] else [0]):
   i0=max(1,int((pt['x']-pt['width']/2-.35)/G)-1);i1=min(NX-2,int((pt['x']+pt['width']/2+.35)/G)+1)
   j0=max(1,int((pt['y']-pt['height']/2-.35)/G)-1);j1=min(NY-2,int((pt['y']+pt['height']/2+.35)/G)+1)
   for i in range(i0,i1+1):
    for j in range(j0,j1+1):
     if ck(pt,pt['width'],pt['height'],.28,i,j):OWN[l][(i,j)].add(pt['net'] or '#FLOAT')
# Prevent B.Cu (ground) net around antenna module near antenna connection except explicit antenna net.
# Board has few vias, ground polygon is later added on B.Cu.

steps=[(1,0,1),(0,1,1),(-1,0,1),(0,-1,1)]
paths=[];vias=[];stats={};groundvias=[]

def free(l,i,j,net):
 if i<1 or i>=NX-1 or j<1 or j>=NY-1:return False
 return not (OWN[l].get((i,j),set())-{net})

def astar(net,start,goals,max_iter=100000):
 si,sj=node(start['x'],start['y']);startset=[]
 for l in ([0,1] if start['thru'] else [0]):
  if free(l,si,sj,net):startset.append((l,si,sj))
 if not startset:return None
 tgt=set()
 for pt in goals:
  i,j=node(pt['x'],pt['y'])
  for l in ([0,1] if pt['thru'] else [0]):
   tgt.add((l,i,j))
 if not tgt:return None
 heap=[];Dcost={};parent={}
 def heur(st):
  l,i,j=st
  return min(math.hypot(i-ii,j-jj)+(6 if l!=ll else 0) for ll,ii,jj in tgt)
 for p in startset: Dcost[p]=0;heapq.heappush(heap,(heur(p),0,p))
 count=0
 while heap and count<max_iter:
  _,dist,u=heapq.heappop(heap);count+=1
  if dist>Dcost.get(u,1e10)+1e-8:continue
  if u in tgt:
   chain=[u]
   while u in parent:
    u=parent[u];chain.append(u)
   chain.reverse();return chain
  l,i,j=u
  for dx,dy,weight in steps:
   ni,nj=i+dx,j+dy
   if not free(l,ni,nj,net):continue
   # diagonal corner shorting: require both axis neighbor traversable
   if dx and dy and (not free(l,i+dx,j,net) or not free(l,i,j+dy,net)):continue
   v=(l,ni,nj);val=dist+weight
   if val+1e-8<Dcost.get(v,1e10):Dcost[v]=val;parent[v]=u;heapq.heappush(heap,(val+heur(v),val,v))
  # Via transitions: center and surrounding grid must clear 0.3 via radius +0.2 clearance
  safe=all(free(0,ci,cj,net) and free(1,ci,cj,net) for ci in [i-1,i,i+1] for cj in [j-1,j,j+1])
  if safe:
   v=(1-l,i,j);val=dist+7.0
   if val+1e-8<Dcost.get(v,1e10):Dcost[v]=val;parent[v]=u;heapq.heappush(heap,(val+heur(v),val,v))
 return None

def occupy(net,chain):
 for l,i,j in chain:
  OWN[l][(i,j)].add(net)
 for u,v in zip(chain,chain[1:]):
  if u[0]!=v[0]:
   _,i,j=u
   for l in (0,1):
    for ii in (i-1,i,i+1):
     for jj in (j-1,j,j+1):
      OWN[l][(ii,jj)].add(net)

def simplify(chain):
 if len(chain)<=2:return chain
 out=[chain[0]]
 for k in range(1,len(chain)-1):
  a,b,c=out[-1],chain[k],chain[k+1]
  if a[0]!=b[0] or b[0]!=c[0]:out.append(b);continue
  if (b[1]-a[1])*(c[2]-b[2])==(b[2]-a[2])*(c[1]-b[1]):continue
  out.append(b)
 return out+[chain[-1]]

# All non-GND netpads (PTH is automatically both-layer)
# Sort globally: high-count rails first (makes routing somewhat harder but shares trees)
non_gnd={n:v for n,v in TERMS.items() if n!='GND'}
priority=['ANT','RF_DATA','MCU_DATA','BUTTON','PGATE','DGATE','BASE_INTERLOCK','SINK_GATE','BASE_POWER','SCK','MISO','MOSI','RESET','POWER','DISCHARGE','BUTTON_RAW','SWVIN','UPDI','BAT','TX3V3','3V3']
allnets=sorted(non_gnd,key=lambda n:(priority.index(n) if n in priority else 99,-len(non_gnd[n])))
failed=[]
for net in allnets:
 term=non_gnd[net]
 if len(term)<2:
  stats[net]={'connected':len(term),'total':len(term),'reason':'single pad'};continue
 used=[term[0]];pending=term[1:]
 # route nearest partner to any point already in tree; as a quick approximation to MST.
 while pending:
  options=sorted((math.hypot(v['x']-u['x'],v['y']-u['y']),v,u) for v in pending for u in used)
  done=False
  for _,v,u in options[:min(len(options),18)]:
   chain=astar(net,v,[u],max_iter=45000)
   if chain:
    simp=simplify(chain)
    paths.append((net,v,u,simp));occupy(net,chain);used.append(v);pending.remove(v);done=True;break
  if not done:break
 stats[net]={'connected':len(used),'total':len(term),'paths':len(used)-1}
 if pending:failed.append((net,[(x['ref'],x['pin']) for x in pending]))
 print(net,stats[net],flush=True)

# Ground pads to B.Cu plane. Route the F.Cu bridge using A* rather than a blind
# straight segment; this prevents intersecting existing signal traces.
groundroutes=[]
connectors=[x for x in TERMS.get('GND',[]) if x['thru']]
for pt in TERMS.get('GND',[]):
 if pt['thru']:continue
 i,j=node(pt['x'],pt['y'])
 candidates=[]
 for dx in range(-14,15):
  for dy in range(-14,15):
   ii,jj=i+dx,j+dy
   if 1<=ii<NX-1 and 1<=jj<NY-1 and all(free(l,x,y,'GND') for l in [0,1] for x in [ii-1,ii,ii+1] for y in [jj-1,jj,jj+1]):
    candidates.append((dx*dx+dy*dy,ii,jj))
 solved=False
 # First try an ordinary plated via. Fall back to an existing ground via or a PTH ground pad.
 for _,ii,jj in sorted(candidates)[:min(35,len(candidates))]:
  goal={'x':ii*G,'y':jj*G,'thru':False,'net':'GND'}
  chain=astar('GND',pt,[goal],max_iter=80000)
  if chain and chain[-1][0]==0:
   groundvias.append((pt,ii,jj));groundroutes.append((pt,goal,chain));occupy('GND',chain)
   for layer in [0,1]:
    for x in [ii-1,ii,ii+1]:
     for y in [jj-1,jj,jj+1]: OWN[layer][(x,y)].add('GND')
   connectors.append(goal)
   solved=True;break
 if not solved:
  for goal in sorted(connectors,key=lambda v:(v['x']-pt['x'])**2+(v['y']-pt['y'])**2):
   chain=astar('GND',pt,[goal],max_iter=85000)
   if chain and all(t[0]==0 for t in chain):
    groundroutes.append((pt,goal,chain));occupy('GND',chain)
    solved=True;break
 if not solved:
  failed.append(('GND',[(pt['ref'],pt['pin'])]))

# Write KiCad track / via data, no Gerbers created until independent DRC zero.
s=BOARD.read_text();assert s.endswith(')')
segments=[]
for k,(net,a,b,chain) in enumerate(paths):
 simplified=simplify(chain)
 # attach exact pad center to route endpoints. Duplicate points near pad centers are allowable on same net.
 x,y=a['x'],a['y'];lx,ly=coord(chain[0][1],chain[0][2]);ln=chain[0][0]
 if (x,y)!=(lx,ly):segments.append((net,ln,(x,y),(lx,ly),k,'src'))
 for ind,(u,v) in enumerate(zip(simplified,simplified[1:])):
  if u[0]!=v[0]:
   vias.append((net,coord(u[1],u[2]),k,ind));continue
  segments.append((net,u[0],coord(u[1],u[2]),coord(v[1],v[2]),k,ind))
 x,y=b['x'],b['y'];lx,ly=coord(chain[-1][1],chain[-1][2]);ln=chain[-1][0]
 if (x,y)!=(lx,ly):segments.append((net,ln,(lx,ly),(x,y),k,'dst'))
# GND pad top routing through reviewed raster A* paths.
for pt,goal,chain in groundroutes:
 simp=simplify(chain)
 first=coord(simp[0][1],simp[0][2]);last=coord(simp[-1][1],simp[-1][2]);
 if first!=(pt['x'],pt['y']):segments.append(('GND',0,(pt['x'],pt['y']),first,pt['ref'],'gndsrc'))
 for ind,(u,v) in enumerate(zip(simp,simp[1:])):
  if u[0]!=v[0]:continue
  segments.append(('GND',0,coord(u[1],u[2]),coord(v[1],v[2]),pt['ref'],('gnd',ind)))
 if last!=(goal['x'],goal['y']):segments.append(('GND',0,last,(goal['x'],goal['y']),pt['ref'],'gnddst'))
for pt,i,j in groundvias:
 vias.append(('GND',coord(i,j),pt['ref'],'gnd'))

lines=[]
for net,l,a,b,ix,sub in segments:
 if a==b:continue
 lines.append(f'''(segment (start {a[0]:.4f} {a[1]:.4f})(end {b[0]:.4f} {b[1]:.4f})(width 0.25)(layer {"F.Cu" if l==0 else "B.Cu"})(net {netids[net]})(uuid "{uid((net,l,a,b,ix,sub))}"))''')
for net,(x,y),ix,sub in vias:
 lines.append(f'''(via (at {x:.4f} {y:.4f})(size 0.75)(drill 0.35)(layers "F.Cu" "B.Cu")(net {netids[net]})(uuid "{uid(('via',net,x,y,ix,sub))}"))''')
# B.Cu GND filled zone (KiCad will calculate fills)
lines.append(f'''(zone (net {netids['GND']}) (net_name "GND") (layer "B.Cu") (uuid "{uid('gndzone')}")
 (hatch edge 0.5) (priority 1) (connect_pads (clearance 0.3)) (min_thickness 0.25) (fill yes (thermal_gap 0.3)(thermal_bridge_width 0.35))
 (polygon (pts (xy 0.35 0.35) (xy 29.65 0.35) (xy 29.65 69.65) (xy 0.35 69.65))))''')
out.write_text(s[:-1]+'\n'+'\n'.join(lines)+'\n)',encoding='utf-8')
report={'status':'ROUTING_EXPERIMENT_NOT_FAB_RELEASE','remaining_net_chains':failed,'net_routes':stats,'track_segments':len(segments),'vias':len(vias),'ground_vias':len(groundvias),'grid_mm':G,'design_rule_check':'NOT RUN - Requires KiCad 8 DRC and manual RF review'}
(ROOT/'validation'/'experimental_route_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('ROUTER',len(segments),'tracks',len(vias),'vias',len(failed),'FAILS',failed)
