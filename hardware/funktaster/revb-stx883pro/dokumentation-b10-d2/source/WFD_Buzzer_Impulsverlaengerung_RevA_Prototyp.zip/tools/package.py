"""Verify reviewed artifacts and create the prototype download. No device access."""
import argparse,csv,hashlib,json,zipfile
import xml.etree.ElementTree as ET
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def ihex(path):
    memory={};base=0;ended=False
    for line in path.read_text().splitlines():
        assert line.startswith(':');raw=bytes.fromhex(line[1:]);assert sum(raw)%256==0
        count,kind=raw[0],raw[3];assert len(raw)==count+5
        address=int.from_bytes(raw[1:3],'big')
        if kind==0:
            for i,value in enumerate(raw[4:-1]):memory[base+address+i]=value
        elif kind==4:base=int.from_bytes(raw[4:-1],'big')<<16
        elif kind==1:ended=True
        else:assert kind in (2,3,5),kind
    assert ended and memory and min(memory)==0 and max(memory)<4096
    return bytes(memory.get(i,255) for i in range(max(memory)+1))

def verify():
    d=json.loads((ROOT/'design.json').read_text())
    assert d['board_mm']==[30,25] and len(d['parts'])==26
    drc=json.loads((ROOT/'validation/drc.json').read_text())
    assert not drc['violations'] and not drc['unconnected_items'] and not drc['schematic_parity']
    erc=(ROOT/'validation/erc.rpt').read_text();assert 'Errors 0' in erc and 'Warnings 0' in erc
    assert 'PASS:' in (ROOT/'validation/controller-test.txt').read_text()
    expected={(p['ref'],pin):('/'+net if net else None) for p in d['parts'] for pin,net in p['pins'].items()}
    actual={}
    for net in ET.parse(ROOT/'validation/netlist.xml').getroot().findall('./nets/net'):
        for node in net.findall('node'):actual[(node.get('ref'),node.get('pin'))]=net.get('name')
    for key,net in expected.items():
        assert key in actual,key
        if net is not None:assert actual[key]==net,(key,actual[key],net)
        else:assert actual[key].startswith('unconnected-'),(key,actual[key])
    fw=ROOT/'firmware';manifest=json.loads((fw/'manifest.json').read_text())
    for name,checksum in manifest['hashes'].items():assert digest(fw/name)==checksum,name
    assert ihex(fw/'buzzer-hold.hex')==(fw/'buzzer-hold.bin').read_bytes()
    fuses=json.loads((fw/'fuses.json').read_text());assert fuses['SYSCFG0']=='0xf6' and fuses['BODCFG']=='0x56' and fuses['OSCCFG']=='0x7e'
    with (ROOT/'BOM.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f,delimiter=';'))
    assert {r['Referenz'] for r in rows}=={p['ref'] for p in d['parts']}
    for name in ('Anleitung_RevA.pdf','Bestueckung_RevA.pdf','Schaltplan_RevA.pdf'):
        assert (ROOT/'documents'/name).read_bytes().startswith(b'%PDF-')
    (ROOT/'validation/software-checks.json').write_text(json.dumps({
        'checked_utc':datetime.now(timezone.utc).isoformat(),'prototype':True,'hardware_validated':False,
        'erc_errors':0,'erc_warnings':0,'drc_violations':0,'unconnected_items':0,'schematic_parity_issues':0,
        'components':26,'firmware_flash_bytes':len(ihex(fw/'buzzer-hold.hex')),
        'checks':['pin/net inventory vs exported schematic','board vs schematic parity','host state-machine tests',
                  'firmware source and artifact hashes','Intel HEX checksums and binary equality','BOM complete',
                  'PDFs rendered and visually inspected','physical tests explicitly open']},indent=2)+'\n',encoding='utf-8',newline='\n')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    # Keep Git checkouts and the downloadable file inventory byte-compatible.
    binary={'.pdf','.bin','.zip','.elf','.png'}
    for path in ROOT.rglob('*'):
        if path.is_file() and path.suffix not in binary and '__pycache__' not in path.parts:
            raw=path.read_bytes()
            try:raw.decode('utf-8')
            except UnicodeDecodeError:continue
            normalized=raw.replace(b'\r\n',b'\n')
            if path.suffix in {'.svg','.ses'}:normalized=b'\n'.join(line.rstrip() for line in normalized.split(b'\n'))
            if path.name=='CC-BY-SA-4.0.txt':normalized=normalized.rstrip()+b'\n'
            if normalized!=raw:path.write_bytes(normalized)
    verify();args.output.mkdir(parents=True,exist_ok=True)
    fabrication=ROOT/'manufacturing';gerbers=[p for p in fabrication.iterdir() if p.suffix in {'.gtl','.gbl','.gtp','.gto','.gbo','.gts','.gbs','.gm1','.drl','.gbrjob'}]
    assert len(gerbers)==11,len(gerbers)
    with zipfile.ZipFile(fabrication/'Gerber_RevA_Prototyp.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(gerbers):z.write(p,p.name)
    files=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
           and not p.name.endswith(('.elf','.kicad_prl')) and '-unrouted.' not in p.name
           and p.name not in {'routing.log','checksums.json'} and '-backups' not in str(p)]
    inventory={p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(files)}
    (ROOT/'checksums.json').write_text(json.dumps({'format':'wfd-hardware-files-1','revision':'A','version':'0.1.0-prototype','hardware_validated':False,'files':inventory},indent=2)+'\n',encoding='utf-8',newline='\n')
    target=args.output/'WFD_Buzzer_Impulsverlaengerung_RevA_Prototyp.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in [*files,ROOT/'checksums.json']:z.write(p,p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        for name,item in inventory.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']
    target.with_suffix('.zip.sha256').write_text(digest(target)+'  '+target.name+'\n',encoding='ascii')
    print('Verified prototype ZIP:',target,';',len(files)+1,'files;',target.stat().st_size,'bytes')

if __name__=='__main__':main()
