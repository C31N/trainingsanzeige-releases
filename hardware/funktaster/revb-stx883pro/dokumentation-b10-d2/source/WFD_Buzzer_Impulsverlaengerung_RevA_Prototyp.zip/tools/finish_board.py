from pathlib import Path
import json,subprocess
import xml.etree.ElementTree as ET
import pcbnew as pcb
ROOT=Path(__file__).resolve().parents[1];d=ROOT/'kicad';validation=ROOT/'validation';validation.mkdir(exist_ok=True)
board=pcb.LoadBoard(str(d/'buzzer-hold-unrouted.kicad_pcb'))
assert pcb.ImportSpecctraSES(board,str(d/'buzzer-hold.ses'))
# Keep local-label scope and explicit NC net names identical to Eeschema.
subprocess.run(['kicad-cli','sch','export','netlist','--format','kicadxml','--output',str(validation/'netlist.xml'),str(d/'buzzer-hold.kicad_sch')],check=True)
for net in list(board.GetNetsByNetcode().values()):
 if net.GetNetname():net.SetNetname('/'+net.GetNetname())
expected={}
for net in ET.parse(validation/'netlist.xml').getroot().findall('./nets/net'):
 for node in net.findall('node'):expected[(node.get('ref'),node.get('pin'))]=net.get('name')
for fp in board.GetFootprints():
 for pad in fp.Pads():
  name=expected.get((fp.GetReference(),pad.GetNumber()))
  if name:
   net=board.FindNet(name)
   if not net:
    net=pcb.NETINFO_ITEM(board,name);board.Add(net)
   pad.SetNet(net)
removed=[]
for attempt in range(8):
 pcb.SaveBoard(str(d/'buzzer-hold.kicad_pcb'),board)
 subprocess.run(['kicad-cli','pcb','drc','--format','json','--schematic-parity','--output',str(validation/'drc.json'),str(d/'buzzer-hold.kicad_pcb')],check=True)
 result=json.loads((validation/'drc.json').read_text())
 dangling={item['uuid'] for v in result['violations'] if v['type']=='track_dangling' for item in v['items']}
 if not dangling:break
 for track in list(board.GetTracks()):
  if track.m_Uuid.AsString() in dangling:board.Remove(track);removed.append(track.m_Uuid.AsString())
else:raise RuntimeError('Dangling cleanup did not converge')
assert not result['violations'] and not result['unconnected_items'] and not result.get('schematic_parity'),result
(validation/'routing-cleanup.json').write_text(json.dumps({'removed_dangling_stubs':len(removed),'tracks_and_vias':len(list(board.GetTracks()))},indent=2))
print('DRC and schematic parity clean; no unconnected pads; removed',len(removed),'router stubs')
