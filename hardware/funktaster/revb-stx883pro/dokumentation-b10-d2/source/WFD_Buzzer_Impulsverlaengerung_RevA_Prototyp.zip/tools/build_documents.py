"""Generate the assembly PDF, readable manual and supplier BOM."""
import csv,json,re
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Preformatted,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).resolve().parents[1]
FONTDIR=Path('C:/Windows/Fonts')
pdfmetrics.registerFont(TTFont('Guide',str(FONTDIR/'arial.ttf')))
pdfmetrics.registerFont(TTFont('GuideBold',str(FONTDIR/'arialbd.ttf')))
pdfmetrics.registerFont(TTFont('GuideMono',str(FONTDIR/'consola.ttf')))
pdfmetrics.registerFontFamily('Guide',normal='Guide',bold='GuideBold')
NAVY=colors.HexColor('#073653');BLUE=colors.HexColor('#007ba8')
GREY=colors.HexColor('#e5edf2')
D=json.loads((ROOT/'design.json').read_text())
with (ROOT/'BOM.csv').open('w',encoding='utf-8-sig',newline='') as f:
    out=csv.writer(f,delimiter=';');out.writerow(['Referenz','Menge','Wert','Bestellbezeichnung','Footprint','Hinweis'])
    for p in D['parts']:
        note='Pin 1 quadratisch; Stiftleiste optional, Drähte direkt anlöten' if p['ref'].startswith('J') else ''
        if p['ref']=='U2':note='TPS709 ohne A/B-Suffix; EN Pin 3 bleibt offen'
        if p['ref']=='R11':note='100 Ohm, 1 W; Entladeimpuls, keine Dauerlast'
        out.writerow([p['ref'],1,p['value'],p['mpn'] or '2,54-mm-Anschluss / Direktdraht',p['footprint'],note])

def page_footer(c,doc):
    c.saveState();c.setFillColor(NAVY);c.setFont('GuideBold',8)
    c.drawString(18*mm,285*mm,'WFD | Buzzer-Impulsverlängerung | Rev A | PROTOTYP')
    c.setStrokeColor(BLUE);c.line(18*mm,282*mm,192*mm,282*mm)
    c.setFont('Guide',8);c.drawString(18*mm,12*mm,'Elektrische Messung und Funkabnahme noch offen.')
    c.drawRightString(192*mm,12*mm,f'Seite {doc.page}');c.restoreState()

styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='Body',fontName='Guide',fontSize=9,leading=12,spaceAfter=6,textColor=NAVY))
styles.add(ParagraphStyle(name='TitleWFD',fontName='GuideBold',fontSize=19,leading=23,spaceAfter=12,textColor=NAVY))
styles.add(ParagraphStyle(name='H2WFD',fontName='GuideBold',fontSize=13,leading=17,spaceBefore=12,spaceAfter=7,textColor=BLUE,keepWithNext=True))
styles.add(ParagraphStyle(name='CodeWFD',fontName='GuideMono',fontSize=6.8,leading=9,spaceAfter=9,backColor=GREY,borderPadding=7))
story=[];buffer=[];code=[];incode=False
def formatted(s):
    s=escape(s);s=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',s)
    return re.sub(r'`([^`]+)`',r'<font name="GuideMono">\1</font>',s)
def flush():
    if buffer:story.append(Paragraph(formatted(' '.join(buffer)),styles['Body']));buffer.clear()
for line in (ROOT/'README.md').read_text(encoding='utf-8').splitlines():
    if line.startswith('```'):
        flush()
        if incode:
            story.append(Preformatted('\n'.join(code),styles['CodeWFD']));code=[]
        incode=not incode;continue
    if incode:code.append(line);continue
    if not line.strip():flush();continue
    if line.startswith('# '):flush();story.append(Paragraph(escape(line[2:]),styles['TitleWFD']));continue
    if line.startswith('## '):flush();story.append(Paragraph(escape(line[3:]),styles['H2WFD']));continue
    if line.startswith('- '):flush();story.append(Paragraph('• '+formatted(line[2:]),styles['Body']));continue
    if re.match(r'^\d+\. ',line):flush()
    buffer.append(line.strip())
flush()
doc=SimpleDocTemplate(str(ROOT/'documents/Anleitung_RevA.pdf'),pagesize=A4,
    rightMargin=18*mm,leftMargin=18*mm,topMargin=24*mm,bottomMargin=23*mm,
    title='WFD Buzzer-Impulsverlängerung Rev A - Prototyp',author='SV Wasserfreunde Dalum e.V.')
doc.build(story,onFirstPage=page_footer,onLaterPages=page_footer)

# Assembly coordinates come from the actual final PCB, not a separate drawing.
c=canvas.Canvas(str(ROOT/'documents/Bestueckung_RevA.pdf'),pagesize=A4)
c.setTitle('Bestückung und Anschlüsse - WFD Rev A Prototyp')
page_footer(c,type('Page',(),{'page':1})())
c.setFont('GuideBold',18);c.setFillColor(NAVY);c.drawString(18*mm,269*mm,'Bestückungsseite Rev A')
c.setFont('Guide',9);c.drawString(18*mm,260*mm,'Ansicht von oben · 5-fach vergrößert · Originalmaß 30 × 25 mm')
scale=5*mm;ox=30*mm;oy=122*mm
def point(x,y):return ox+x*scale,oy+(25-y)*scale
c.setFillColor(colors.HexColor('#eff6f9'));c.setStrokeColor(NAVY);c.rect(ox,oy,30*scale,25*scale,fill=1)
geometry=json.loads((ROOT/'validation/board_geometry.json').read_text())
for part in geometry:
    for pad in part['pads']:
        x,y=point(pad['x'],pad['y']);w=pad['w']*scale;h=pad['h']*scale
        c.setFillColor(colors.HexColor('#dca74c'));c.setStrokeColor(NAVY);c.setLineWidth(.3)
        c.rect(x-w/2,y-h/2,w,h,fill=1)
        if pad['hole']:
            c.setFillColor(colors.white);c.circle(x,y,pad['hole']*scale/2,fill=1)
        c.setFillColor(NAVY);c.setFont('GuideBold',6);c.drawCentredString(x,y-2,pad['number'])
    x,y=point(part['x'],part['y']);c.setFillColor(colors.white)
    width=pdfmetrics.stringWidth(part['ref'],'GuideBold',8)+4
    c.rect(x-width/2,y-4,width,10,fill=1,stroke=0)
    c.setFillColor(NAVY);c.setFont('GuideBold',8);c.drawCentredString(x,y-2,part['ref'])
    one=next((p for p in part['pads'] if p['number']=='1'),None)
    if one and not part['ref'].startswith(('R','C')):
        x1,y1=point(one['x'],one['y']);c.setFillColor(colors.HexColor('#bb3044'));c.circle(x1-4,y1+4,1.6,fill=1,stroke=0)
c.setFont('Guide',9);c.setFillColor(NAVY)
lines=[
 'Rot markiert: Pin 1 bei IC, Transistor, Diode und Anschluss.',
 'D1: Pad 1 = Kathode (Strich), Pad 2 = Anode.',
 'Q1/Q3: 1 = Gate, 2 = Source, 3 = Drain. Q2/Q4: 1 = Basis, 2 = Emitter, 3 = Kollektor.',
 'J1: 1 BAT+ hinter Sicherung, 2 GND. J2: 1 Taster NO, 2 Taster COM/GND.',
 'J3: 1 OUT+ zur V5 09-A, 2 GND zur V5 07-A.',
 'J4 von oben nach unten: 1 UPDI, 2 3V3, 3 GND. Keine 5 V anschließen.',
 'U2 unbedingt TPS70933DBVR: EN Pin 3 offen lassen; kein TPS709A/B-Ersatz.',
 'Alle Bauteile oben. Unterseite: Leiterbahnen und Durchkontaktierungen.',
 'Noch nicht elektrisch oder am Funkempfänger freigegeben.'
]
for index,line in enumerate(lines):c.drawString(18*mm,(109-index*7)*mm,line)
c.save()
print('BOM and two documentation PDFs created.')
