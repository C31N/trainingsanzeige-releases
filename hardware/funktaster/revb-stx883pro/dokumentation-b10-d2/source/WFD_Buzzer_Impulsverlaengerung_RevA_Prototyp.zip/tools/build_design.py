#!/usr/bin/env python3
"""Generate self-contained KiCad 8 sources from the reviewed pin/net inventory.
Run using KiCad's Python (pcbnew) on Linux. Routing is a separate step.
"""
import json,uuid,math,shutil
from pathlib import Path
import pcbnew as pcb
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/'design.json').read_text());OUT=ROOT/'kicad';OUT.mkdir(exist_ok=True)
def uid(key):return str(uuid.uuid5(uuid.NAMESPACE_URL,'wfd-buzzer-hold-A/'+key))
def q(s):return json.dumps(str(s),ensure_ascii=False)
def effects(size=1):return f"""(effects (font (size {size} {size})))"""
rootid=uid('schematic');symbols=[];instances=[];labels=[]
allparts=list(D['parts'])+[
 {'ref':'#FLG01','value':'BAT_POWER','pins':{'1':'BAT'},'types':{'1':'power_out'},'footprint':''},
 {'ref':'#FLG02','value':'GND_POWER','pins':{'1':'GND'},'types':{'1':'power_out'},'footprint':''}]
order=['J1','U2','C2','C3','U1','C1','J4','#FLG01','Q1','Q2','R3','R4','D1','R5','R6','#FLG02','Q3','Q4','R7','R8','R9','R10','R11','J3','J2','R1','R2','C4']
allparts.sort(key=lambda c:order.index(c['ref']))
for index,c in enumerate(allparts):
 ref=c['ref'];name='WFD:'+ref.replace('#','');pins=list(c['pins']);half=math.ceil(len(pins)/2);height=max(5.08,(half+1)*2.54)
 graphics=f"""(symbol "{ref.replace('#','')}_0_1" (rectangle (start -7.62 {-height/2}) (end 7.62 {height/2}) (stroke (width 0.254) (type default)) (fill (type background))))"""
 pinxml=[];positions={}
 for n,num in enumerate(pins):
  side=0 if n<half else 1;row=n if side==0 else n-half
  x=-10.16 if side==0 else 10.16;y=(half-1)*1.27-row*2.54
  positions[num]=(x,y)
  typename=c.get('types',{}).get(num,'passive');pinname=D.get('pin_names',{}).get(ref,{}).get(num,num)
  pinxml.append(f"""(pin {typename} line (at {x} {y} {0 if side==0 else 180}) (length 2.54) (name {q(pinname)} {effects(.85)}) (number {q(num)} {effects(.85)}))""")
 symshort=ref.replace('#','')
 symbols.append(f"""(symbol {q(name)} (pin_names (offset 0.5)) (in_bom yes) (on_board yes) (property "Reference" {q(ref)} (at 0 {height/2+4} 0) {effects()}) (property "Value" {q(c['value'])} (at 0 {height/2+1.5} 0) {effects(.85)}) {graphics} (symbol "{symshort}_1_1" {" ".join(pinxml)}))""")
 x=45.72+(index%4)*101.6;y=30.48+(index//4)*35.56
 instances.append(f"""(symbol (lib_id {q(name)}) (at {x} {y} 0) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid {q(uid(ref))}) (property "Reference" {q(ref)} (at {x} {y-height/2-4} 0) {effects()}) (property "Value" {q(c['value'])} (at {x} {y-height/2-1.5} 0) {effects(.85)}) (property "Footprint" {q('WFD:'+c['footprint'].split(':')[-1] if c['footprint'] else '')} (at {x} {y} 0) (effects (font (size 1 1)) hide)) (instances (project "buzzer-hold" (path {q('/'+rootid)} (reference {q(ref)}) (unit 1)))))""")
 for num,net in c['pins'].items():
  dx,dy=positions[num];px=x+dx;py=y-dy
  if net is None and c.get('types',{}).get(num)=='no_connect':continue
  if net is None:labels.append(f"""(no_connect (at {px} {py}) (uuid {q(uid(ref+num+'nc'))}))""")
  else:
   ex=px+(-3.81 if dx<0 else 3.81)
   labels.append(f"""(wire (pts (xy {px} {py}) (xy {ex} {py})) (stroke (width 0) (type default)) (uuid {q(uid(ref+num+'wire'))}))""")
   justify='right' if dx<0 else 'left'
   labels.append(f"""(label {q(net)} (at {ex} {py} 0) (effects (font (size .85 .85)) (justify {justify} bottom)) (uuid {q(uid(ref+num+'label'))}))""")
sch=f"""(kicad_sch (version 20231120) (generator "eeschema") (uuid {q(rootid)}) (paper "A3") (title_block (title "WFD Buzzer Impulsverlaengerung") (rev "A - PROTOTYP") (company "Wasserfreunde Dalum") (comment 1 "6-12 V BAT / 3.3 V MCU; UPDI; 1000 ms ON + 100 ms discharge") (comment 2 "Pin-labelled functional symbols; PROTOTYPE - no physical acceptance yet")) (lib_symbols {" ".join(symbols)}) {" ".join(labels+instances)} (sheet_instances (path "/" (page "1"))))"""
(OUT/'buzzer-hold.kicad_sch').write_text(sch,encoding='utf-8')
(OUT/'WFD.kicad_sym').write_text('(kicad_symbol_lib (version 20231120) (generator kicad_symbol_editor) '+ ' '.join(x.replace('(symbol \"WFD:', '(symbol \"',1) for x in symbols)+')',encoding='utf-8')
(OUT/'sym-lib-table').write_text('(sym_lib_table (lib (name \"WFD\")(type \"KiCad\")(uri \"${KIPRJMOD}/WFD.kicad_sym\")(options \"\")(descr \"Reviewed pin-labelled parts\")))',encoding='utf-8')
board=pcb.BOARD();board.SetCopperLayerCount(2)
settings=board.GetDesignSettings();settings.m_MinClearance=pcb.FromMM(.2);settings.m_TrackMinWidth=pcb.FromMM(.2);settings.m_ViasMinSize=pcb.FromMM(.6);settings.m_MinThroughDrill=pcb.FromMM(.3)
nets={}
for name in sorted({net for c in D['parts'] for net in c['pins'].values() if net}):
 net=pcb.NETINFO_ITEM(board,name);board.Add(net);nets[name]=net
local=OUT/'WFD.pretty';local.mkdir(exist_ok=True)
for c in D['parts']:
 lib,fn=c['footprint'].split(':');source=Path('/usr/share/kicad/footprints')/(lib+'.pretty')/(fn+'.kicad_mod')
 shutil.copyfile(source,local/(fn+'.kicad_mod'))
 fp=pcb.FootprintLoad(str(local),fn);assert fp is not None,c['ref'];fp.SetReference(c['ref']);fp.SetValue(c['value']);fp.SetFPID(pcb.LIB_ID('WFD',fn));fp.SetPath(pcb.KIID_PATH('/'+rootid+'/'+uid(c['ref'])))
 fp.SetPosition(pcb.VECTOR2I(pcb.FromMM(c['xy'][0]),pcb.FromMM(c['xy'][1])))
 fp.Value().SetVisible(False);fp.Reference().SetVisible(True)
 for pad in fp.Pads():
  net=c['pins'].get(pad.GetNumber());
  if net:pad.SetNet(nets[net])
 board.Add(fp)
 # References deliberately on fab, with no silk/pad collisions on compact PCB.
 for txt in [fp.Reference(),fp.Value()]:txt.SetLayer(pcb.F_Fab)
for start,end in [((0,0),(30,0)),((30,0),(30,25)),((30,25),(0,25)),((0,25),(0,0))]:
 seg=pcb.PCB_SHAPE();seg.SetShape(pcb.SHAPE_T_SEGMENT);seg.SetStart(pcb.VECTOR2I(pcb.FromMM(start[0]),pcb.FromMM(start[1])));seg.SetEnd(pcb.VECTOR2I(pcb.FromMM(end[0]),pcb.FromMM(end[1])));seg.SetLayer(pcb.Edge_Cuts);seg.SetWidth(pcb.FromMM(.05));board.Add(seg)
for text,x,y,size in [('PROTOTYP A',16,24,.8),('BAT+',2.3,.8,.8),('KEY',2.3,13.8,.8),('OUT+',27.2,.8,.8),('UPDI',27.5,15.2,.8)]:
 t=pcb.PCB_TEXT(board);t.SetText(text);t.SetPosition(pcb.VECTOR2I(pcb.FromMM(x),pcb.FromMM(y)));t.SetTextSize(pcb.VECTOR2I(pcb.FromMM(size),pcb.FromMM(size)));t.SetTextThickness(pcb.FromMM(.1));t.SetLayer(pcb.F_SilkS);board.Add(t)
pcb.SaveBoard(str(OUT/'buzzer-hold-unrouted.kicad_pcb'),board)
(OUT/'fp-lib-table').write_text('(fp_lib_table (lib (name "WFD")(type "KiCad")(uri "${KIPRJMOD}/WFD.pretty")(options "")(descr "Self-contained standard footprints")))',encoding='utf-8')
(OUT/'buzzer-hold.kicad_pro').write_text(json.dumps({'meta':{'filename':'buzzer-hold.kicad_pro','version':1},'board':{'design_settings':{'rules':{'min_clearance':.2,'min_track_width':.2,'min_via_diameter':.6,'min_through_hole_diameter':.3}}}},indent=2),encoding='utf-8')
print('Generated schematic and board:',len(D['parts']),'parts;',len(nets),'nets')

assert pcb.ExportSpecctraDSN(board,str(OUT/'buzzer-hold.dsn'))
