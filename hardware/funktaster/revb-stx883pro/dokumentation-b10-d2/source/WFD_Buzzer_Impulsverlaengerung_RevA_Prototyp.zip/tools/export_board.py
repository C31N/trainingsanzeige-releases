"""Export manufacturing data and measured pad geometry using KiCad Python."""
import json, subprocess
from pathlib import Path
import pcbnew as pcb

ROOT=Path(__file__).resolve().parents[1]
boardfile=ROOT/'kicad/buzzer-hold.kicad_pcb'
target=ROOT/'manufacturing';target.mkdir(exist_ok=True)
board=pcb.LoadBoard(str(boardfile))
components=[]
for fp in board.GetFootprints():
    pads=[]
    for p in fp.Pads():
        pads.append({'number':p.GetNumber(),'x':pcb.ToMM(p.GetPosition().x),
                     'y':pcb.ToMM(p.GetPosition().y),'w':pcb.ToMM(p.GetSize().x),
                     'h':pcb.ToMM(p.GetSize().y),'net':p.GetNetname(),
                     'hole':pcb.ToMM(p.GetDrillSize().x)})
    components.append({'ref':fp.GetReference(),'value':fp.GetValue(),
        'x':pcb.ToMM(fp.GetPosition().x),'y':pcb.ToMM(fp.GetPosition().y),'pads':pads})
(ROOT/'validation/board_geometry.json').write_text(json.dumps(components,indent=2))
subprocess.run(['kicad-cli','pcb','export','gerbers','--output',str(target)+'/',
    '--layers','F.Cu,B.Cu,F.Paste,F.Silkscreen,B.Silkscreen,F.Mask,B.Mask,Edge.Cuts',
    '--subtract-soldermask',str(boardfile)],check=True)
subprocess.run(['kicad-cli','pcb','export','drill','--output',str(target)+'/',
    '--format','excellon','--excellon-units','mm','--excellon-separate-th',str(boardfile)],check=True)
subprocess.run(['kicad-cli','pcb','export','pos','--output',str(target/'positions.csv'),
    '--format','csv','--units','mm',str(boardfile)],check=True)
subprocess.run(['kicad-cli','pcb','export','svg','--output',str(ROOT/'documents/pcb-top.svg'),
    '--layers','F.Cu,F.Silkscreen,Edge.Cuts','--page-size-mode','2',
    '--exclude-drawing-sheet',str(boardfile)],check=True)
