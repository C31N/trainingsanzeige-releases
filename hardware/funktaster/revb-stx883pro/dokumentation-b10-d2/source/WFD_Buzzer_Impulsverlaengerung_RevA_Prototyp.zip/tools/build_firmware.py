#!/usr/bin/env python3
"""Build ATtiny402 firmware only. Never opens a programmer or serial port."""
import argparse,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--toolchain',type=Path,required=True);parser.add_argument('--dfp',type=Path,required=True);args=parser.parse_args()
 def tool(name):
  p=args.toolchain/(name+'.exe');return str(p if p.exists() else args.toolchain/name)
 out=ROOT/'firmware';elf=out/'buzzer-hold.elf'
 command=[tool('avr-gcc'),'-mmcu=attiny402','-B',str(args.dfp/'gcc/dev/attiny402')+'/', '-I',str(args.dfp/'include'),'-Os','-std=gnu11','-Wall','-Wextra','-Werror','-ffunction-sections','-fdata-sections','-Wl,--gc-sections',str(out/'main.c'),'-o',str(elf)]
 subprocess.run(command,check=True)
 for fmt,suffix in [('ihex','.hex'),('binary','.bin')]:subprocess.run([tool('avr-objcopy'),'-O',fmt,'-R','.eeprom',str(elf),str(out/('buzzer-hold'+suffix))],check=True)
 hexfile=out/'buzzer-hold.hex';hexfile.write_bytes(hexfile.read_bytes().replace(b'\r\n',b'\n'))
 sizes=subprocess.check_output([tool('avr-size'),str(elf)],text=True)
 numbers=sizes.splitlines()[1].split();assert int(numbers[0])+int(numbers[1])<=4096 and int(numbers[1])+int(numbers[2])<256
 (out/'buzzer-hold.lst').write_text(subprocess.check_output([tool('avr-objdump'),'-d',str(elf)],text=True).replace(str(elf),'buzzer-hold.elf'),encoding='utf-8')
 manifest={'firmware':'1.0.0-prototype','device':'ATtiny402','cpu_hz':5000000,'dfp':'Microchip.ATtiny_DFP.3.4.278','compiler':subprocess.check_output([tool('avr-gcc'),'--version'],text=True).splitlines()[0],'size':sizes.replace(str(elf),'buzzer-hold.elf'),'hashes':{n:digest(out/n) for n in ['main.c','controller.h','fuses.json','buzzer-hold.hex','buzzer-hold.bin']},'physical_validation':False}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');print(sizes)
if __name__=='__main__':main()
