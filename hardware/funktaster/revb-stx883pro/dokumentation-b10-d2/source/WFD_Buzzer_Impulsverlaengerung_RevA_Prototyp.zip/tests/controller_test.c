#include <assert.h>
#include <stdio.h>
#include "../firmware/controller.h"
static void advance(controller_t *s,int pressed,int ms){while(ms--){controller_step(s,pressed,1);assert(!(controller_power(s)&&controller_discharge(s)));}}
int main(void){
 for(int duration=1;duration<=50;duration++){
  controller_t s;controller_init(&s);advance(&s,0,120);assert(s.phase==ARMED);
  controller_step(&s,1,0);assert(controller_power(&s));advance(&s,1,duration);
  advance(&s,0,999-duration);assert(controller_power(&s));advance(&s,0,1);assert(!controller_power(&s));
  advance(&s,0,119);assert(s.phase==WAIT_RELEASE);advance(&s,0,1);assert(s.phase==ARMED);
 }
 controller_t s;controller_init(&s);advance(&s,1,3000);assert(!controller_power(&s));
 advance(&s,0,19);assert(s.phase!=ARMED);advance(&s,1,1);advance(&s,0,20);assert(s.phase==ARMED);
 controller_step(&s,1,0);advance(&s,1,3000);assert(!controller_power(&s));assert(s.phase==WAIT_RELEASE);
 advance(&s,0,20);controller_step(&s,1,0);assert(controller_power(&s));
 for(int i=0;i<100;i++){advance(&s,0,1);advance(&s,1,1);}assert(controller_power(&s));
 advance(&s,0,800);assert(s.phase==DISCHARGING);advance(&s,1,100);advance(&s,0,20);assert(s.phase==ARMED);
 controller_step(&s,1,0);controller_init(&s);assert(!controller_power(&s));
 puts("PASS: 1..50 ms presses, hold, discharge, release, bounce, held startup, lockout, reset, interlock.");
}
