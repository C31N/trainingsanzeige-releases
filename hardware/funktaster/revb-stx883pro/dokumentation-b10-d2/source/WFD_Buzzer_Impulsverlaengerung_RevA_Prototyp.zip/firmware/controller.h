#ifndef WFD_HOLD_CONTROLLER_H
#define WFD_HOLD_CONTROLLER_H
#include <stdint.h>
#define HOLD_MS 1000U
#define DISCHARGE_MS 100U
#define RELEASE_MS 20U
typedef enum { DISCHARGING, WAIT_RELEASE, ARMED, SENDING } phase_t;
typedef struct { phase_t phase; uint16_t elapsed; uint8_t released; } controller_t;
static inline void controller_init(controller_t *s){s->phase=DISCHARGING;s->elapsed=0;s->released=0;}
/* One elapsed millisecond, or dt=0 on an asynchronous input edge.
 * First filtered closure wins; no press is queued during lockout. */
static inline void controller_step(controller_t *s,uint8_t pressed,uint8_t dt){
 switch(s->phase){
 case DISCHARGING:s->elapsed+=dt;if(s->elapsed>=DISCHARGE_MS){s->phase=WAIT_RELEASE;s->elapsed=0;s->released=0;}break;
 case WAIT_RELEASE:s->released=pressed?0:(uint8_t)(s->released+dt);if(s->released>=RELEASE_MS){s->phase=ARMED;s->elapsed=0;}break;
 case ARMED:if(pressed){s->phase=SENDING;s->elapsed=0;s->released=0;}break;
 case SENDING:s->elapsed+=dt;if(s->elapsed>=HOLD_MS){s->phase=DISCHARGING;s->elapsed=0;s->released=0;}break;
 }
}
static inline uint8_t controller_power(const controller_t *s){return s->phase==SENDING;}
static inline uint8_t controller_discharge(const controller_t *s){return s->phase!=SENDING;}
#endif
