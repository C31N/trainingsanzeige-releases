/* Rev A: ATtiny402, 3.3 V, 20 MHz/4. PA1/pin4 POWER, PA2/pin5 BUTTON,
 * PA3/pin7 DISCHARGE; PA0/pin6 remains UPDI. Existing sender unchanged. */
#define F_CPU 5000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/cpufunc.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include "controller.h"
static volatile uint8_t tick,edge;
ISR(TCB0_INT_vect){TCB0.INTFLAGS=TCB_CAPT_bm;tick=1;}
ISR(PORTA_PORT_vect){PORTA.INTFLAGS=PIN2_bm;edge=1;}
static uint8_t pressed(void){return !(VPORTA.IN&PIN2_bm);}
static uint8_t was_power;
static void drive(const controller_t *s){
 if(controller_power(s)){PORTA.OUTCLR=PIN3_bm;PORTA.OUTSET=PIN1_bm;}
 else {PORTA.OUTCLR=PIN1_bm;if(was_power)_delay_ms(1);PORTA.OUTSET=PIN3_bm;}
 was_power=controller_power(s);
}
static void watchdog(uint8_t enable){
 while(WDT.STATUS&WDT_SYNCBUSY_bm){}
 _PROTECTED_WRITE(WDT.CTRLA,enable?WDT_PERIOD_2KCLK_gc:0);
 while(WDT.STATUS&WDT_SYNCBUSY_bm){}
}
int main(void){
 PORTA.OUTCLR=PIN1_bm|PIN3_bm;PORTA.DIRSET=PIN1_bm|PIN3_bm;
 PORTA.PIN2CTRL=PORT_ISC_BOTHEDGES_gc;
 PORTA.PIN6CTRL=PORT_ISC_INPUT_DISABLE_gc;PORTA.PIN7CTRL=PORT_ISC_INPUT_DISABLE_gc;
 _PROTECTED_WRITE(CLKCTRL.MCLKCTRLB,CLKCTRL_PDIV_4X_gc|CLKCTRL_PEN_bm);
 ADC0.CTRLA=0;AC0.CTRLA=0;
 TCB0.CCMP=4999;TCB0.INTCTRL=TCB_CAPT_bm;TCB0.CTRLA=TCB_CLKSEL_CLKDIV1_gc|TCB_ENABLE_bm;
 controller_t state;controller_init(&state);drive(&state);watchdog(1);sei();
 for(;;){
  cli();uint8_t elapsed=tick;tick=0;uint8_t changed=edge;edge=0;
  if(elapsed||changed){sei();controller_step(&state,pressed(),elapsed?1:0);drive(&state);wdt_reset();continue;}
  uint8_t sleeping=(state.phase==ARMED&&!pressed())||(state.phase==WAIT_RELEASE&&pressed());
  if(sleeping){
   TCB0.CTRLA=0;watchdog(0);
   if(edge||((state.phase==ARMED)==(pressed()!=0))){watchdog(1);TCB0.CNT=0;TCB0.CTRLA=TCB_CLKSEL_CLKDIV1_gc|TCB_ENABLE_bm;sei();continue;}
   set_sleep_mode(SLEEP_MODE_PWR_DOWN);
  }else set_sleep_mode(SLEEP_MODE_IDLE);
  sleep_enable();sei();sleep_cpu();sleep_disable();
  if(sleeping){watchdog(1);TCB0.CNT=0;TCB0.CTRLA=TCB_CLKSEL_CLKDIV1_gc|TCB_ENABLE_bm;}
 }
}
