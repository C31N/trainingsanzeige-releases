#!/usr/bin/env python3
"""Generate exploratory Rev B 30x70mm KiCad schematic, footprint placement PCB,
BOM and assembly placement. NOT an autorouted/fabrication-ready board.
Source: V5 and RevA public release documents, STX883PRO Rev1.1 datasheet.
"""
import json,uuid,re,math,csv,copy,zipfile,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'kicad/WFD-RevB.pretty' # self-contained copied Rev A library footprints
OUT=ROOT/'kicad';OUT.mkdir(exist_ok=True)

def U(key):return str(uuid.uuid5(uuid.NAMESPACE_URL, 'wfd:revB:stx883pro:'+str(key)))
def q(t):return json.dumps(str(t),ensure_ascii=False)
def part(ref,value,fp,pins,xy,lcsc='',mpn='',note='',rot=0,kind='smd'):
    return dict(ref=ref,value=value,fp=fp,pins=pins,xy=xy,rot=rot,lcsc=lcsc,mpn=mpn,note=note,kind=kind)
P=[]
def A(*args,**kw):P.append(part(*args,**kw))
# 9-V VERICO via *external 250mA fuse*, fused input J1, reverse polarity Schottky D2.
A('J1','9V_AKKU_FUSED','HEADER_1x02',{'1':'BAT_FUSED','2':'GND'},[5.2,64.0],kind='hand')
A('J2','TASTER_COM_NO','HEADER_1x02',{'1':'BUTTON_RAW','2':'GND'},[13.0,64.0],kind='hand')
A('J3','433MHz_ANT_50OHM','HEADER_1x01',{'1':'ANT'},[19.73,3.2],kind='hand')
A('J4','CTRL_UPDI_3V3_GND','HEADER_1x03',{'1':'UPDI','2':'3V3','3':'GND'},[20.5,63.2],kind='hand')
A('J5','DIAMEX_ISP','HEADER_2x03',{'1':'MISO','2':'TX3V3','3':'SCK','4':'MOSI','5':'RESET','6':'GND'},[5.0,35.0],kind='hand')
A('D2','SS14 Reverse','D_SMA',{'1':'BAT','2':'BAT_FUSED'},[4.5,57.0],'C2480','SS14','Cathode pin1 toward BAT net')
# RevA hold controller unchanged except 9V BAT is after D2.
A('U1','ATtiny402-SSN','SOIC-8_3.9x4.9mm_P1.27mm',{'1':'3V3','2':None,'3':None,'4':'POWER','5':'BUTTON','6':'UPDI','7':'DISCHARGE','8':'GND'},[12.0,47.3],'C1339884','ATTINY402-SSN')
A('U2','TPS70933 CTRL','SOT-23-5',{'1':'BAT','2':'GND','3':None,'4':None,'5':'3V3'},[6.0,52.6],'C89347','TPS70933DBVR','Enable pin 3 NC per specific variant')
A('Q1','AO3407A HS','SOT-23',{'1':'PGATE','2':'BAT','3':'SWVIN'},[23.0,54.1],'C15155','AO3407A')
A('Q2','MMBT3904','SOT-23',{'1':'BASE_POWER','2':'GND','3':'SINK_GATE'},[18.5,56.0],'C7422625','MMBT3904LT1G')
A('Q3','AO3400A','SOT-23',{'1':'DGATE','2':'GND','3':'DRAIN_DISCHARGE'},[22.0,47.0],'C20917','AO3400A')
A('Q4','MMBT3904','SOT-23',{'1':'BASE_INTERLOCK','2':'GND','3':'DGATE'},[17.8,50.1],'C7422625','MMBT3904LT1G')
A('D1','BZT52C10','D_SOD-123',{'1':'BAT','2':'PGATE'},[26.1,50.0],'C2103','BZT52C10','Zener reference plus/cathode pin1 on BAT')
res={'R1':('10k','3V3','BUTTON',[11.0,40.0]),'R2':('1k','BUTTON_RAW','BUTTON',[10.0,61.2]),'R3':('100k','BAT','PGATE',[27.0,58.0]),'R4':('10k','PGATE','SINK_GATE',[23.3,59.5]),'R5':('10k','POWER','BASE_POWER',[16.0,59.5]),'R6':('100k','BASE_POWER','GND',[26.0,62.0]),'R7':('10k','DISCHARGE','DGATE',[18.2,43.0]),'R8':('100k','DGATE','GND',[26.1,46.3]),'R9':('10k','POWER','BASE_INTERLOCK',[13.6,51.4]),'R10':('100k','BASE_INTERLOCK','GND',[12.5,58.0]),'R11':('100R','SWVIN','DRAIN_DISCHARGE',[25.0,43.0]),'R12':('10k','TX3V3','RESET',[8.0,28.0]),'R13':('150R','MCU_DATA','RF_DATA',[21.5,27.5]),'R14':('10k','RF_DATA','GND',[26.0,28.5]),'R15':('330R','TX3V3','GND',[18.0,35.5])}
for ref,(value,p1,p2,xy) in res.items():
 code= {'10k':'C84376','1k':'C95781','100k':'C96346','100R':'C844884','150R':'C114523','330R':'C105878'}[value]
 footprint = 'R_2512_6332Metric' if ref=='R11' else 'R_0805_2012Metric'
 A(ref,value,footprint,{'1':p1,'2':p2},xy,code,value,'R11 pulse rating 1W' if ref=='R11' else '')
# Original hold board capacitors + active transmitter rail filter (SMD, no electrolytics).
caps={'C1':('100n','3V3',[10.0,51.8]),'C2':('1u','BAT',[11.0,54.8]),'C3':('4.7u','3V3',[5.5,49.2]),'C4':('100n','BUTTON',[3.4,44.7]),'C5':('1u','SWVIN',[27.0,34.5]),'C6':('4.7u','TX3V3',[25.0,32.0]),'C7':('100n','TX3V3',[14.5,35.5]),'C8':('10u','TX3V3',[8.0,23.7]),'C9':('100n','TX3V3',[19.0,23.6])}
for ref,(value,net,xy) in caps.items():
 code={'100n':'C1711','1u':'C77080','4.7u':'C76639','10u':'C6119932'}[value]
 A(ref,value,'C_0805_2012Metric',{'1':net,'2':'GND'},xy,code,value)
# Integrated 3.3V transmitter supply: TPS70933 max150mA; RF TX ~9mA @3.3V.
A('U3','TPS70933 TX','SOT-23-5',{'1':'SWVIN','2':'GND','3':None,'4':None,'5':'TX3V3'},[22.7,38.6],'C89347','TPS70933DBVR')
# ATtiny13A-SSU has same 8-pin SOIC assignment as ATtiny13A-PU DIP.
A('U4','ATtiny13A V2','SOIC-8_3.9x4.9mm_P1.27mm',{'1':'RESET','2':'MCU_DATA','3':None,'4':'GND','5':'MOSI','6':'MISO','7':'SCK','8':'TX3V3'},[14.0,31.2],'C14075','ATTINY13A-SSU','Original V2 HEX for IDs 1-5; verify port timing')
A('U5','STX883PRO-433MHz','STX883PRO',{'1':'GND','2':'TX3V3','3':'RF_DATA','4':'ANT'},[15.0,12.5],'C3001517','STX883PRO-433MHz','Custom footprint based on Rev1.1 datasheet; NOT factory-verified land pattern')
# Additional optional M2, unplated holes (must measure case).
A('H1','Mount M2','MountingHole_2.2',{},[4.0,5.0],kind='mechanical')
A('H2','Mount M2','MountingHole_2.2',{},[26.0,66.0],kind='mechanical')
order={x['ref']:x for x in P};assert len(order)==len(P)
netnames=sorted({v for p in P for v in p['pins'].values() if v})
D={'revision':'B0.1-preliminary','status':'SCHEMATIC_AND_PLACEMENT_ONLY_NO_ROUTING','width_mm':30.0,'height_mm':70.0,'bom_5':5,'rf':{'part':'STX883PRO-433MHz','lcsc':'C3001517','frequency_mhz':433.92,'voltage_v':3.3,'max_tx_power_dBm':10,'notes':'Legal ERP and duty-cycle must be checked on final product'},'parts':P,'nets':netnames}
(ROOT/'design.json').write_text(json.dumps(D,ensure_ascii=False,indent=2),encoding='utf-8')

def embedded_block(text,start):
    depth=0;in_quote=False;esc=False
    for i in range(start,len(text)):
        c=text[i]
        if in_quote:
            if esc:esc=False
            elif c=='\\':esc=True
            elif c=='"':in_quote=False
        else:
            if c=='"':in_quote=True
            elif c=='(':depth+=1
            elif c==')':
                depth-=1
                if depth==0:return text[start:i+1]
    raise RuntimeError('Unterminated expression')

# Standard KiCad 8 footprints from original checked release, no speculative pad dimensions except STX module.
LIB=OUT/'WFD-RevB.pretty';LIB.mkdir(exist_ok=True)
base_footprints=['C_0805_2012Metric','D_SOD-123','R_0805_2012Metric','R_2512_6332Metric','SOIC-8_3.9x4.9mm_P1.27mm','SOT-23-5','SOT-23','PinHeader_1x02_P2.54mm_Vertical','PinHeader_1x03_P2.54mm_Vertical']
for f in base_footprints:(LIB/f'{f}.kicad_mod').write_bytes((BASE/f'{f}.kicad_mod').read_bytes())
# Use exact footprint from trusted library for J1/J2/J4.
def smd_pad(no,x,y,sx,sy,shape='roundrect'):
    return f'(pad "{no}" smd {shape} (at {x} {y}) (size {sx} {sy}) (layers "F.Cu" "F.Paste" "F.Mask")'+ (' (roundrect_rratio 0.15)' if shape=='roundrect' else '') +')'
def th_pad(no,x,y,diam=2.0,drill=1.0):
    return f'(pad "{no}" thru_hole circle (at {x} {y}) (size {diam} {diam}) (drill {drill}) (layers "*.Cu" "*.Mask"))'
def custom(name,body,attr='smd'):
    s=f'''(footprint "{name}" (version 20240108) (generator "pcbnew") (layer "F.Cu")
      (property "Reference" "REF**" (at 0 -9 0) (layer "F.Fab") (effects (font (size 0.8 0.8)(thickness 0.1))))
      (property "Value" "{name}" (at 0 9 0) (layer "F.Fab") (effects (font (size 0.8 0.8)(thickness 0.1))))
      (attr {attr}) {body})'''
    (LIB/f'{name}.kicad_mod').write_text(s,encoding='utf-8')
# Footprint based on manufacturer's Rev1.1 mechanical drawing (pads 1-3 bottom, 4 top).
# Exact recommended land geometry is NOT published. Do not manufacture before vendor PCB land verification!
custom('STX883PRO',f'''(fp_rect (start -7.06 -6.765111) (end 7.06 7.904889) (stroke (width 0.1) (type default)) (fill none) (layer "F.Fab"))
  (fp_rect (start -7.4 -7.1) (end 7.4 8.7) (stroke (width 0.05) (type default)) (fill none) (layer "F.CrtYd"))
  (fp_text user "ANT TOP" (at 1.5 -4.5) (layer "F.Fab") (effects (font (size 0.8 0.8) (thickness 0.10))))
  (pad "1" smd rect (at -2.54 7.1) (size 1.9 2.7) (layers "F.Cu" "F.Paste" "F.Mask"))
  (pad "2" smd rect (at 0 7.1) (size 1.9 2.7) (layers "F.Cu" "F.Paste" "F.Mask"))
  (pad "3" smd rect (at 2.54 7.1) (size 1.9 2.7) (layers "F.Cu" "F.Paste" "F.Mask"))
  (pad "4" smd rect (at 4.72999 -6.05517) (size 2 2.5) (layers "F.Cu" "F.Paste" "F.Mask"))''')
custom('D_SMA',f'''(fp_rect (start -2.6 -1.4)(end 2.6 1.4)(stroke (width 0.1)(type default))(fill none)(layer "F.Fab"))
  {smd_pad(1,-2.75,0,2.1,2.2)} {smd_pad(2,2.75,0,2.1,2.2)}''')
custom('HEADER_1x01',th_pad(1,0,0),attr='through_hole')
custom('HEADER_2x03',' '.join(th_pad(str(i),x,y) for i,(x,y) in enumerate([(0,0),(2.54,0),(0,2.54),(2.54,2.54),(0,5.08),(2.54,5.08)],1)),attr='through_hole')
custom('MountingHole_2.2','(pad "" np_thru_hole circle (at 0 0) (size 2.2 2.2) (drill 2.2) (layers "*.Cu" "*.Mask"))',attr='exclude_from_pos_files exclude_from_bom')
# Mapping from conceptual connectors to trusted library names.
FPALIASES={'HEADER_1x02':'PinHeader_1x02_P2.54mm_Vertical','HEADER_1x03':'PinHeader_1x03_P2.54mm_Vertical'}
def fpmod(p):return FPALIASES.get(p['fp'],p['fp'])

def add_net_to_footprint(src,p,nets):
    src=src.replace(f'(footprint "{fpmod(p)}"',f'(footprint "WFD-RevB:{fpmod(p)}"',1)
    src=src.replace('(layer "F.Cu")',f'(layer "F.Cu") (at {p["xy"][0]} {p["xy"][1]} {p["rot"]}) (uuid "{U(p["ref"])}")',1)
    src=re.sub(r'\(property "Reference" "REF\*\*"',f'(property "Reference" "{p["ref"]}"',src,count=1)
    src=re.sub(r'\(property "Value" "[^"]+"',f'(property "Value" {q(p["value"])}',src,count=1)
    # Place component reference on Fab layer only; labels will be engineered later.
    st=src.find('(property "Reference"')
    if st>=0:
        blk=embedded_block(src,st)
        src=src[:st]+blk.replace('(layer "F.SilkS")','(layer "F.Fab")')+src[st+len(blk):]
    src=src.replace('(attr smd)',f'(attr {"smd" if p["kind"]=="smd" else "through_hole"})',1) if p['kind']!='smd' else src
    new=''; idx=0
    while True:
        st=src.find('(pad ',idx)
        if st<0:new+=src[idx:];break
        new+=src[idx:st];end=st+len(embedded_block(src,st));el=src[st:end]
        m=re.match(r'\(pad "(.*?)"',el);no=m.group(1) if m else ''
        net=p['pins'].get(no)
        if net:
            # Pad net assigned according to owner netlist; never guess NC nets.
            el=el[:-1]+f' (net {nets[net]} {q(net)})'+')'
        new+=el;idx=end
    return new

netids={n:i+1 for i,n in enumerate(netnames)}
head=f'''(kicad_pcb (version 20240108) (generator "pcbnew")
  (general (thickness 1.6)) (paper "A4")
  (layers (0 "F.Cu" signal)(31 "B.Cu" signal)(32 "B.Adhes" user)(33 "F.Adhes" user)
  (34 "B.Paste" user)(35 "F.Paste" user)(36 "B.SilkS" user)(37 "F.SilkS" user)
  (38 "B.Mask" user)(39 "F.Mask" user)(44 "Edge.Cuts" user)(49 "F.Fab" user)(50 "B.Fab" user))
  (net 0 "")\n'''+''.join(f'  (net {n} {q(k)})\n' for k,n in netids.items())
board=[head]
for p in P:
    content=(LIB/(fpmod(p)+'.kicad_mod')).read_text(encoding='utf-8')
    board.append('  '+add_net_to_footprint(content,p,netids)+'\n')
for (x,y,x2,y2) in [(0,0,30,0),(30,0,30,70),(30,70,0,70),(0,70,0,0)]:
    board.append(f'''(gr_line (start {x} {y}) (end {x2} {y2}) (stroke (width 0.05)(type default)) (layer "Edge.Cuts") (uuid "{U(('edge',x,y))}"))\n''')
# Silkscreen text intentionally deferred until clearance-verified placement.
board.append(')')
(OUT/'buzzer-revb-stx883pro-PLACEMENT-ONLY.kicad_pcb').write_text(''.join(board),encoding='utf-8')
(OUT/'fp-lib-table').write_text('(fp_lib_table (lib (name "WFD-RevB")(type "KiCad")(uri "${KIPRJMOD}/WFD-RevB.pretty")(options "")(descr "WFD Rev B prototype custom footprints")))',encoding='utf-8')
(OUT/'buzzer-revb-stx883pro.kicad_pro').write_text(json.dumps({'meta':{'filename':'buzzer-revb-stx883pro.kicad_pro','version':1}},indent=2),encoding='utf-8')
# Symbolic schematic: explicit one symbol per part and net name labels. Generated netlist is authoritative.
S=[];instance=[];labels=[]
rootid=U('root')
def eff(sz=1):return f'(effects (font (size {sz} {sz})))'
for ix,p in enumerate(P):
    # Include H1/H2 no-pin schematic symbols for footprint parity.
    ref=p['ref'];pins=list(p['pins']);half=math.ceil(len(pins)/2);height=max(5.08,(half+1)*2.54);x=31.75+(ix%4)*95.25;y=25.4+(ix//4)*30.48
    # A2 page: all 40 electrical symbols fit on a 4x10 grid; do not wrap.
    n='WFD-RevB:'+ref
    pinxml=[];pos={}
    for j,num in enumerate(pins):
        side=j>=half;row=j-half if side else j;px=10.16 if side else -10.16;py=(half-1)*1.27-row*2.54
        pos[num]=px,py
        pinxml.append(f'''(pin passive line (at {px} {py} {180 if side else 0}) (length 2.54) (name {q(num)} {eff(.8)}) (number {q(num)} {eff(.8)}))''')
    S.append(f'''(symbol {q(n)} (pin_names (offset 0.5)) (in_bom yes)(on_board yes)
      (property "Reference" {q(ref)} (at 0 {height/2+4} 0) {eff()})
      (property "Value" {q(p['value'])} (at 0 {height/2+2} 0) {eff(.8)})
      (property "Footprint" {q('WFD-RevB:'+fpmod(p))} (at 0 -10 0) (effects (font (size .8 .8)) hide))
      (symbol {q(ref+'_1_1')} (rectangle (start -7.62 {-height/2})(end 7.62 {height/2}) (stroke (width .254)(type default))(fill (type background))) {' '.join(pinxml)}))''')
    instance.append(f'''(symbol (lib_id {q(n)})(at {x} {y} 0)(unit 1)(in_bom yes)(on_board yes)(dnp no)(uuid {q(U('sch_'+ref))})
      (property "Reference" {q(ref)} (at {x} {y-height/2-4} 0) {eff()})
      (property "Value" {q(p['value'])} (at {x} {y-height/2-2} 0) {eff(.8)})
      (property "Footprint" {q('WFD-RevB:'+fpmod(p))} (at {x} {y} 0) (effects (font (size 1 1)) hide))
      (instances (project "buzzer-revb-stx883pro" (path {q('/'+rootid)} (reference {q(ref)})(unit 1)))))''')
    for num,net in p['pins'].items():
        px,py=pos[num];wx=x+px;wy=y-py
        if not net:labels.append(f'(no_connect (at {wx} {wy}) (uuid {q(U(ref+num+"NC"))}))')
        else:
            ex=wx+(3.81 if px>0 else -3.81)
            labels.append(f'(wire (pts (xy {wx} {wy})(xy {ex} {wy})) (stroke (width 0)(type default))(uuid {q(U(ref+num+"w"))}))')
            labels.append(f'(label {q(net)} (at {ex} {wy} 0) (effects (font (size .8 .8))(justify {"left" if px>0 else "right"} bottom)) (uuid {q(U(ref+num+"l"))}))')
sc=f'''(kicad_sch (version 20231120) (generator "eeschema") (uuid {q(rootid)}) (paper "A2")
 (title_block (title "Wasserfreunde Dalum STX883PRO Sender Buzzer") (rev "B0.3 - EXPERIMENT / NO FABRICATION") (company "Wasserfreunde Dalum")
 (comment 1 "V5 V2 firmware on ATtiny13A; RevA hold controller ATtiny402; 9V VERICO to two 3V3 LDOs")
 (comment 2 "FANOUT/ROUTING MISSING - NO FABRICATION FILES"))
 (lib_symbols {' '.join(S)}) {' '.join(labels+instance)} (sheet_instances (path "/" (page "1"))))'''
(OUT/'buzzer-revb-stx883pro.kicad_sch').write_text(sc,encoding='utf-8')
# Project-local schematic symbol library generated from the same embedded symbols.
(OUT/'WFD-RevB.kicad_sym').write_text(
    '(kicad_symbol_lib (version 20231120) (generator "kicad_symbol_editor") '+
    ' '.join(S).replace('(symbol "WFD-RevB:', '(symbol "')+')',encoding='utf-8')
(OUT/'sym-lib-table').write_text(
    '(sym_lib_table (lib (name "WFD-RevB")(type "KiCad")'+
    '(uri "${KIPRJMOD}/WFD-RevB.kicad_sym")(options "")'+
    '(descr "Self-contained WFD Rev B schematic symbols")))',encoding='utf-8')
# JLC BOM and CPL with explicit NOT_RELEASED labeling; actual rotations/land pattern not validated.
with (ROOT/'BOM_JLC_Entwurf_NICHT_FREIGEGEBEN.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['Comment','Designator','Footprint','LCSC Part #','Population'])
    for p in P:
        w.writerow([p['value'],p['ref'],'WFD-RevB:'+fpmod(p),p['lcsc'],p['kind']])
with (ROOT/'CPL_JLC_Entwurf_NICHT_FREIGEGEBEN.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['Designator','Mid X','Mid Y','Layer','Rotation'])
    for p in P:
        if p['kind']=='smd':w.writerow([p['ref'],f'{p["xy"][0]}mm',f'{p["xy"][1]}mm','Top',p['rot']])
with (ROOT/'NETLIST.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['Net','References'])
    for n in netnames:
        w.writerow([n, ', '.join(f'{p["ref"]}.{pad}' for p in P for pad,net in p['pins'].items() if net==n)])
checks={'PCB component count':len(P),'SMD component count':sum(p['kind']=='smd' for p in P),'Nets count':len(netnames),'STX883PRO pinout':order['U5']['pins'],'Status':D['status'],'KiCad DRC':'NOT RUN, ROUTING MISSING','Antenna footprint':'DRAFT requires JLC pin1/2/3/4 land pattern verification','Firmware source':'DIAMEX V2 prebuilt 1-5 and Rev A controller original HEX'}
(ROOT/'validation'/'preflight.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2));print('Generated KiCad preliminary project:',OUT)
