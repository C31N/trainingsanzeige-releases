PROTOTYPE ONLY. JLC footprint, 50-ohm RF, installed ERP, battery under load and MCU firmware NOT validated. DO NOT ASSUME SERIES RELEASE.
