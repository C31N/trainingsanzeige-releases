#!/usr/bin/env python3
"""Add guarded ground-via candidates to Rev B routing experiment.
Geometry-only copper+via clearance screen; not native KiCad DRC or fab signoff.
"""
import re, json, math, uuid
from pathlib import Path
from shapely.geometry import Point,box,LineString
from shapely.strtree import STRtree
ROOT=Path(__file__).resolve().parent
inp=ROOT/'kicad/buzzer-revb-stx883pro-ROUTED-V2-EXPERIMENT.kicad_pcb';out=ROOT/'kicad/buzzer-revb-stx883pro-ROUTED-V3-EXPERIMENT.kicad_pcb'
D=json.loads((ROOT/'design.json').read_text()); NID={n:i+1 for i,n in enumerate(D['nets'])};GND=NID['GND'];PAD_DIR=ROOT/'kicad/WFD-RevB.pretty'
ALIAS={'HEADER_1x02':'PinHeader_1x02_P2.54mm_Vertical','HEADER_1x03':'PinHeader_1x03_P2.54mm_Vertical'}
def block(t,s):
 n=0;quot=False;esc=False
 for k in range(s,len(t)):
  c=t[k]
  if quot:
   if esc:esc=False
   elif c=='\\':esc=True
   elif c=='"':quot=False
  elif c=='"':quot=True
  elif c=='(':n+=1
  elif c==')':
   n-=1
   if n==0:return t[s:k+1]
 raise ValueError()
obs=[]; gndpads=[];drills=[]
for part in D['parts']:
 fp=ALIAS.get(part['fp'],part['fp']);t=(PAD_DIR/(fp+'.kicad_mod')).read_text();idx=0
 while True:
  idx=t.find('(pad ',idx)
  if idx<0:break
  p=block(t,idx);idx+=len(p);m=re.match(r'\(pad "(.*?)"',p);at=re.search(r'\(at\s+([-\d.]+)\s+([-\d.]+)',p);sz=re.search(r'\(size\s+([-\d.]+)\s+([-\d.]+)',p)
  if not m or not at or not sz:continue
  pin=m.group(1);x=part['xy'][0]+float(at.group(1));y=part['xy'][1]+float(at.group(2));w,h=map(float,sz.groups()); net=part['pins'].get(pin);thru='thru_hole' in p
  geom=Point(x,y).buffer(w/2) if ' circle ' in p else box(x-w/2,y-h/2,x+w/2,y+h/2)
  if net=='GND':gndpads.append((part['ref'],pin,x,y,geom))
  elif net is None and thru:drills.append(geom.buffer(1))
  else:obs.append(geom)
s=inp.read_text();
for m in re.finditer(r'\(segment\s+\(start ([-\d.]+) ([-\d.]+)\)\s+\(end ([-\d.]+) ([-\d.]+)\)\s+\(width ([\d.]+)\)\s+\(layer (F.Cu|B.Cu)\)\s+\(net (\d+)\)',s):
 a,b,c,d,w,lay,net=m.groups()
 if int(net)!=GND:obs.append(LineString([(float(a),float(b)),(float(c),float(d))]).buffer(float(w)/2))
for m in re.finditer(r'\(via\s+\(at ([-\d.]+) ([-\d.]+)\)\s+\(size ([\d.]+)\).*?\(net (\d+)\)',s):
 x,y,sz,net=m.groups()
 if int(net)!=GND:obs.append(Point(float(x),float(y)).buffer(float(sz)/2))
obs.extend(drills)
tree=STRtree(obs)
def clearance(x,y,r=.625):
 p=Point(x,y)
 return not any(p.distance(obs[int(i)])<r for i in tree.query(p.buffer(r)))
used=[]
for ref,pin,x,y,geom in gndpads:
 if ref in ('J1','J2','J4','J5'):continue # existing through-hole GND already connects layers
 viable=[]
 for k in range(-16,17):
  for j in range(-16,17):
   nx=round((x+k*.25)*4)/4;ny=round((y+j*.25)*4)/4
   if nx<1.2 or nx>28.8 or ny<1.2 or ny>68.8:continue
   if any(math.hypot(nx-a,ny-b)<2.0 for a,b in used):continue
   if not clearance(nx,ny):continue
   # via copper should not overlap RF module outline; avoid placing vias below module for manual rework
   if 7.6<nx<22.4 and 4.8<ny<20.2:continue
   dist=math.hypot(nx-x,ny-y)
   if dist>.8 and dist<4.2:viable.append((dist,nx,ny))
 if viable:
  _,nx,ny=min(viable);used.append((nx,ny))
lines=[]
for idx,(x,y) in enumerate(used):
 u=str(uuid.uuid5(uuid.NAMESPACE_URL,f'WFD:B0.2:GND_STITCH:{idx}:{x}:{y}'))
 lines.append(f'(via (at {x:.4f} {y:.4f}) (size 0.75) (drill 0.35) (layers "F.Cu" "B.Cu") (net {GND}) (uuid "{u}"))')
out.write_text(s.rstrip()[:-1]+'\n'+'\n'.join(lines)+'\n)')
(ROOT/'validation/ground_stitch.json').write_text(json.dumps({'vias':used,'count':len(used),'note':'Ground connectivity requires filled native KiCad zone and independent DRC; not manufacturing-ready'},indent=2))
print('Inserted',len(used),'ground-via candidates',used)
