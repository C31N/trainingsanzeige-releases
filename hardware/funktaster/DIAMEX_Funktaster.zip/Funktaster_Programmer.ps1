# Wasserfreunde Dalum - Funktaster Programmer
# DIAMEX USB ISP / STK500v2 / ATtiny13A
# Windows PowerShell 5.1+, Windows 10/11

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$FirmwareDir = Join-Path $Root 'firmware'
$ToolsDir = Join-Path $Root 'tools\avrdude'
$LogsDir = Join-Path $Root 'logs'
New-Item -ItemType Directory -Force -Path $ToolsDir, $LogsDir | Out-Null

$ExpectedSignature = '1e9007'
$ExpectedHFuse = '0xfb'
$ExpectedLFuse = '0x76'
$BitClockUs = '10'   # ca. 100 kHz ISP; sicher auch fuer frischen ATtiny13A mit 1,2 MHz
$script:Programming = $false

function Find-Avrdude {
    $p = Join-Path $ToolsDir 'avrdude.exe'
    if (Test-Path $p) { return $p }
    $found = Get-ChildItem -Path $ToolsDir -Filter avrdude.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { return $found.FullName }
    return $null
}

function Find-AvrdudeConf([string]$AvrdudePath) {
    if (-not $AvrdudePath) { return $null }
    $dir = Split-Path -Parent $AvrdudePath
    $candidate = Join-Path $dir 'avrdude.conf'
    if (Test-Path $candidate) { return $candidate }
    $found = Get-ChildItem -Path $dir -Filter avrdude.conf -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { return $found.FullName }
    return $null
}

function Write-Log([string]$Text) {
    $timestamp = Get-Date -Format 'HH:mm:ss'
    $script:LogBox.AppendText("[$timestamp] $Text`r`n")
    $script:LogBox.SelectionStart = $script:LogBox.Text.Length
    $script:LogBox.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

function Save-SessionLog([string]$Text) {
    $name = 'programmer_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.log'
    $path = Join-Path $LogsDir $name
    $Text | Out-File -FilePath $path -Encoding UTF8
    return $path
}

function Install-Avrdude {
    try {
        $arch = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString().ToLowerInvariant()
        switch ($arch) {
            'x64' {
                $url = 'https://github.com/avrdudes/avrdude/releases/download/v8.3/avrdude-v8.3-windows-x64.zip'
                $sha = '8630c7d8bb9682a1685aaa9ad42550ae1131c9d13528f0d20975368ba615e9b0'
            }
            'arm64' {
                $url = 'https://github.com/avrdudes/avrdude/releases/download/v8.3/avrdude-v8.3-windows-arm64.zip'
                $sha = '6fffcecd9b87d2d14c6b9983c4cd41ac3963896c58efd18d630c307c9520620e'
            }
            'x86' {
                $url = 'https://github.com/avrdudes/avrdude/releases/download/v8.3/avrdude-v8.3-windows-x86.zip'
                $sha = '4d0dd70f56f8373bb728093de16e7e5f1b3e0d26ac0e40d57f02df0ad2e4e776'
            }
            default { throw "Nicht unterstuetzte Windows-Architektur: $arch" }
        }

        Write-Log "Lade AVRDUDE 8.3 ($arch) von der offiziellen GitHub-Release-Seite..."
        $tmpZip = Join-Path $env:TEMP ('avrdude_' + [guid]::NewGuid().ToString() + '.zip')
        $tmpDir = Join-Path $env:TEMP ('avrdude_' + [guid]::NewGuid().ToString())
        Invoke-WebRequest -Uri $url -OutFile $tmpZip -UseBasicParsing

        $actual = (Get-FileHash -Algorithm SHA256 -Path $tmpZip).Hash.ToLowerInvariant()
        if ($actual -ne $sha) {
            Remove-Item $tmpZip -Force -ErrorAction SilentlyContinue
            throw "SHA-256 stimmt nicht. Erwartet: $sha  Erhalten: $actual"
        }
        Write-Log 'SHA-256 der AVRDUDE-Datei ist korrekt.'

        New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null
        Expand-Archive -Path $tmpZip -DestinationPath $tmpDir -Force
        $exe = Get-ChildItem -Path $tmpDir -Filter avrdude.exe -Recurse | Select-Object -First 1
        if (-not $exe) { throw 'avrdude.exe wurde im Archiv nicht gefunden.' }
        $sourceDir = Split-Path -Parent $exe.FullName

        if (Test-Path $ToolsDir) { Remove-Item $ToolsDir -Recurse -Force }
        New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
        Copy-Item -Path (Join-Path $sourceDir '*') -Destination $ToolsDir -Recurse -Force

        Remove-Item $tmpZip -Force -ErrorAction SilentlyContinue
        Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue

        $installed = Find-Avrdude
        if (-not $installed) { throw 'AVRDUDE konnte nach dem Entpacken nicht gefunden werden.' }
        Write-Log "AVRDUDE installiert: $installed"
        [System.Windows.Forms.MessageBox]::Show('AVRDUDE 8.3 wurde installiert und geprueft.', 'Installation erfolgreich', 'OK', 'Information') | Out-Null
    }
    catch {
        Write-Log ('FEHLER bei AVRDUDE-Installation: ' + $_.Exception.Message)
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'AVRDUDE-Installation fehlgeschlagen', 'OK', 'Error') | Out-Null
    }
}

function Get-ComPorts {
    $ports = @()
    try {
        $ports = Get-CimInstance Win32_SerialPort | Sort-Object DeviceID | ForEach-Object {
            [PSCustomObject]@{ DeviceID=$_.DeviceID; Display=("{0} - {1}" -f $_.DeviceID,$_.Name) }
        }
    } catch {}
    if (-not $ports -or $ports.Count -eq 0) {
        # Fallback: bekannte COM-Namen aus .NET
        $ports = [System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object | ForEach-Object {
            [PSCustomObject]@{ DeviceID=$_; Display=$_ }
        }
    }
    return $ports
}

function Refresh-Ports {
    $script:PortBox.Items.Clear()
    $ports = @(Get-ComPorts)
    foreach ($p in $ports) {
        [void]$script:PortBox.Items.Add($p.Display)
    }
    if ($script:PortBox.Items.Count -eq 1) {
        $script:PortBox.SelectedIndex = 0
    }
    elseif ($script:PortBox.Items.Count -gt 1) {
        # Wenn moeglich einen typischen USB/DIAMEX-Port vorauswaehlen
        $idx = -1
        for ($i=0; $i -lt $script:PortBox.Items.Count; $i++) {
            $t = $script:PortBox.Items[$i].ToString().ToLowerInvariant()
            if ($t -match 'diamex|usb serial|stk500') { $idx=$i; break }
        }
        if ($idx -ge 0) { $script:PortBox.SelectedIndex=$idx }
    }
    Write-Log ("COM-Ports gefunden: " + $script:PortBox.Items.Count)
}

function Selected-ComPort {
    if (-not $script:PortBox.SelectedItem) { return $null }
    $text = $script:PortBox.SelectedItem.ToString()
    if ($text -match '^(COM\d+)') { return $matches[1] }
    return $text
}

function Invoke-Avrdude([string[]]$ExtraArgs) {
    $avrdude = Find-Avrdude
    if (-not $avrdude) { throw 'AVRDUDE fehlt. Bitte zuerst "AVRDUDE installieren" anklicken.' }
    $port = Selected-ComPort
    if (-not $port) { throw 'Bitte zuerst den COM-Port des DIAMEX auswaehlen.' }

    $args = @()
    $conf = Find-AvrdudeConf $avrdude
    if ($conf) { $args += @('-C', $conf) }
    $args += @('-p','t13a','-c','stk500v2','-P',$port,'-B',$BitClockUs)
    $args += $ExtraArgs

    Write-Log ('AVRDUDE: ' + ($args -join ' '))
    # AVRDUDE writes its normal version/diagnostic output to stderr. In Windows
    # PowerShell 5.1, 2>&1 with ErrorActionPreference=Stop otherwise throws on
    # the first line, hiding the real AVRDUDE exit code and error message.
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $output = & $avrdude @args 2>&1 | Out-String
        $code = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $previousPreference
    }
    foreach ($line in ($output -split "`r?`n")) {
        if ($line.Trim().Length -gt 0) { Write-Log $line }
    }
    $logFile = Save-SessionLog $output
    Write-Log "Detail-Log: $logFile"
    return [PSCustomObject]@{ ExitCode=$code; Output=$output }
}

function Ensure-Ready {
    if (-not (Find-Avrdude)) {
        $r = [System.Windows.Forms.MessageBox]::Show('AVRDUDE ist noch nicht installiert. Jetzt automatisch von der offiziellen AVRDUDE-GitHub-Release-Seite installieren?', 'AVRDUDE fehlt', 'YesNo', 'Question')
        if ($r -eq 'Yes') { Install-Avrdude }
    }
    if (-not (Find-Avrdude)) { return $false }
    if (-not (Selected-ComPort)) {
        [System.Windows.Forms.MessageBox]::Show('Bitte den COM-Port des DIAMEX auswaehlen.', 'COM-Port fehlt', 'OK', 'Warning') | Out-Null
        return $false
    }
    return $true
}

function Test-Target {
    try {
        if (-not (Ensure-Ready)) { return $false }
        Write-Log 'Pruefe ATtiny13A-Verbindung...'
        $r = Invoke-Avrdude @('-v')
        if ($r.ExitCode -ne 0) {
            throw 'Verbindung fehlgeschlagen. Bitte Versorgung, ISP-Stecker, COM-Port und DIAMEX-Schalter pruefen.'
        }
        if ($r.Output.ToLowerInvariant() -notmatch '1e\s*90\s*07|0x1e9007|1e9007') {
            Write-Log 'WARNUNG: Signatur 1E 90 07 wurde im Text nicht eindeutig erkannt. AVRDUDE war jedoch erfolgreich.'
        } else {
            Write-Log 'ATtiny13A-Signatur 1E 90 07 erkannt.'
        }
        $script:StatusLabel.Text = 'Verbindung OK'
        return $true
    }
    catch {
        Write-Log ('FEHLER: ' + $_.Exception.Message)
        $script:StatusLabel.Text = 'Verbindung FEHLER'
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Verbindung fehlgeschlagen', 'OK', 'Error') | Out-Null
        return $false
    }
}

function Get-FuseValues {
    $tmpH = Join-Path $env:TEMP ('hfuse_' + [guid]::NewGuid().ToString() + '.txt')
    $tmpL = Join-Path $env:TEMP ('lfuse_' + [guid]::NewGuid().ToString() + '.txt')
    try {
        $result = Invoke-Avrdude @('-U',("hfuse:r:{0}:h" -f $tmpH),'-U',("lfuse:r:{0}:h" -f $tmpL))
        if ($result.ExitCode -ne 0) { throw 'Fuse-Auslesen fehlgeschlagen. Flash wird nicht geschrieben.' }
        return [PSCustomObject]@{ High=(Get-Content $tmpH -Raw).Trim().ToLowerInvariant(); Low=(Get-Content $tmpL -Raw).Trim().ToLowerInvariant() }
    }
    finally {
        Remove-Item -LiteralPath $tmpH,$tmpL -Force -ErrorAction SilentlyContinue
    }
}

function Program-Buzzer([int]$Id) {
    if ($script:Programming) { return }
    $script:Programming = $true
    $disabledControls = @($form.Controls | Where-Object {
        $_ -is [System.Windows.Forms.Button] -or $_ -is [System.Windows.Forms.ComboBox] -or
        $_ -is [System.Windows.Forms.CheckBox] -or $_ -is [System.Windows.Forms.NumericUpDown]
    } | Where-Object { $_.Enabled })
    foreach ($control in $disabledControls) { $control.Enabled = $false }
    try {
        if ($Id -lt 1 -or $Id -gt 255) { throw 'Die eigene Taster-ID muss zwischen 1 und 255 liegen.' }
        $isV2 = $script:FirmwareProfile.SelectedIndex -eq 1
        if ($isV2 -and -not $script:ReceiverReady.Checked) {
            throw 'Zuerst die neue Empfaengersoftware (diamex-5) auf dem Pi installieren. Danach die Bestaetigung aktivieren. Eine alte Pi-Version erkennt V2 nicht!'
        }
        if (-not $isV2 -and $Id -gt 5) { throw 'Eigene IDs ab 6 sind nur mit Firmware V2 moeglich.' }
        $selectedDirectory = if ($isV2) { Join-Path $FirmwareDir 'v2' } else { $FirmwareDir }
        $hex = Join-Path $selectedDirectory ("buzzer{0}.hex" -f $Id)
        if (-not (Test-Path $hex)) { throw "Firmwaredatei fehlt: $hex" }
        if ($isV2) {
            $manifest = Get-Content (Join-Path $selectedDirectory 'manifest.json') -Raw | ConvertFrom-Json
            $image = $manifest.images.PSObject.Properties[[string]$Id].Value
            if (-not $image -or $manifest.protocol -ne 'Dalum-DIAMEX2' -or $image.id -ne $Id -or $image.bytes -gt 1024) {
                throw 'Ungueltiger V2-Firmwarekatalog.'
            }
            if ((Get-FileHash -LiteralPath $hex -Algorithm SHA256).Hash.ToLowerInvariant() -ne $image.sha256_hex) {
                throw 'Die Firmware-Pruefsumme stimmt nicht. Paket neu herunterladen; nicht programmieren.'
            }
            Write-Log ("V2 / ID {0} / Code {1} / SHA256 geprueft" -f $Id,$image.code)
        }
        if (-not (Ensure-Ready)) { return }

        $msg = @"
Vor dem Programmieren pruefen:

1. DIAMEX: BEIDE Target-Spannungsschalter OFF.
2. 6-poliges ISP-Kabel korrekt, Pin 1 beachten.
3. Funktaster selbst einschalten: grossen Taster gedrueckt halten.
4. Am Funktaster liegen ca. 3,3 V an.
5. Taster bis zur Erfolgsmeldung NICHT loslassen.

Firmware: $(if ($isV2) { 'V2 - Zeitstempel, Ereignisnummer und versetzte Wiederholungen' } else { 'V1 - bisherige Firmware' })
Jetzt Buzzer $Id programmieren? Kein Training oder Spiel darf dabei laufen.
"@
        $answer = [System.Windows.Forms.MessageBox]::Show($msg, "Buzzer $Id programmieren", 'YesNo', 'Warning')
        if ($answer -ne 'Yes') { Write-Log "Programmierung Buzzer $Id abgebrochen."; return }

        if (-not (Test-Target)) { return }

        $currentFuses = Get-FuseValues
        if ($currentFuses.High -eq $ExpectedHFuse -and $currentFuses.Low -eq $ExpectedLFuse) {
            Write-Log 'Fuses sind bereits korrekt und werden nicht erneut geschrieben.'
        }
        else {
            Write-Log "Setze sichere Funktaster-Fuses: HFUSE=$ExpectedHFuse, LFUSE=$ExpectedLFuse"
            $fuse = Invoke-Avrdude @('-U',"hfuse:w:${ExpectedHFuse}:m",'-U',"lfuse:w:${ExpectedLFuse}:m")
            if ($fuse.ExitCode -ne 0) { throw 'Fuse-Programmierung fehlgeschlagen. Flash wird nicht geschrieben.' }
        }

        Write-Log "Programmiere Firmware fuer Buzzer $Id..."
        $flash = Invoke-Avrdude @(
            '-e',
            '-U',("flash:w:{0}:i" -f $hex),
            '-U',("flash:v:{0}:i" -f $hex)
        )
        if ($flash.ExitCode -ne 0) { throw 'Flashen oder Verifizieren fehlgeschlagen.' }

        Write-Log "Buzzer $Id erfolgreich programmiert und verifiziert."
        $script:StatusLabel.Text = "Buzzer ${Id}: ERFOLGREICH"
        [System.Windows.Forms.MessageBox]::Show(
            "Buzzer $Id wurde erfolgreich programmiert und verifiziert.`r`n`r`nJetzt Taster loslassen, ISP-Kabel abziehen und einen normalen Funktionstest machen.",
            'Programmierung erfolgreich','OK','Information') | Out-Null
    }
    catch {
        Write-Log ('FEHLER: ' + $_.Exception.Message)
        $script:StatusLabel.Text = 'Programmierung FEHLER'
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Programmierung fehlgeschlagen', 'OK', 'Error') | Out-Null
    }
    finally {
        foreach ($control in $disabledControls) { $control.Enabled = $true }
        $script:Programming = $false
    }
}

function Read-Fuses {
    try {
        if (-not (Ensure-Ready)) { return }
        $tmpH = Join-Path $env:TEMP ('hfuse_' + [guid]::NewGuid().ToString() + '.txt')
        $tmpL = Join-Path $env:TEMP ('lfuse_' + [guid]::NewGuid().ToString() + '.txt')
        $r = Invoke-Avrdude @('-U',("hfuse:r:{0}:h" -f $tmpH),'-U',("lfuse:r:{0}:h" -f $tmpL))
        if ($r.ExitCode -ne 0) { throw 'Fuse-Auslesen fehlgeschlagen.' }
        $hf = (Get-Content $tmpH -Raw).Trim().ToLowerInvariant()
        $lf = (Get-Content $tmpL -Raw).Trim().ToLowerInvariant()
        Remove-Item $tmpH,$tmpL -Force -ErrorAction SilentlyContinue
        Write-Log "Gelesen: HFUSE=$hf, LFUSE=$lf"
        $ok = (($hf -eq $ExpectedHFuse) -and ($lf -eq $ExpectedLFuse))
        $text = "HFUSE: $hf (Soll $ExpectedHFuse)`r`nLFUSE: $lf (Soll $ExpectedLFuse)"
        if ($ok) { $text += "`r`n`r`nFuses sind korrekt." } else { $text += "`r`n`r`nFuses weichen vom Soll ab." }
        [System.Windows.Forms.MessageBox]::Show($text,'Fuse-Kontrolle','OK', $(if($ok){'Information'}else{'Warning'})) | Out-Null
    }
    catch {
        Write-Log ('FEHLER: ' + $_.Exception.Message)
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Fuse-Kontrolle fehlgeschlagen','OK','Error') | Out-Null
    }
}

# ---------------- GUI ----------------
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Wasserfreunde Dalum - Funktaster Programmer'
$form.Size = New-Object System.Drawing.Size(780,790)
$form.StartPosition = 'CenterScreen'
$form.MinimumSize = New-Object System.Drawing.Size(780,790)
$form.Add_FormClosing({ param($sender,$eventArgs) if ($script:Programming) { $eventArgs.Cancel = $true } })

$title = New-Object System.Windows.Forms.Label
$title.Text = 'DIAMEX USB ISP - Funktaster programmieren'
$title.Font = New-Object System.Drawing.Font('Segoe UI',16,[System.Drawing.FontStyle]::Bold)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(18,15)
$form.Controls.Add($title)

$info = New-Object System.Windows.Forms.Label
$info.Text = "ATtiny13A | STK500v2 | 3,3-V-Zielschaltung | PB3 = Funk-DATA`r`nWichtig: DIAMEX-Targetversorgung fuer den fertigen Funktaster auf OFF lassen."
$info.AutoSize = $true
$info.Location = New-Object System.Drawing.Point(20,52)
$form.Controls.Add($info)

$portLabel = New-Object System.Windows.Forms.Label
$portLabel.Text = 'DIAMEX COM-Port:'
$portLabel.Location = New-Object System.Drawing.Point(20,102)
$portLabel.AutoSize = $true
$form.Controls.Add($portLabel)

$script:PortBox = New-Object System.Windows.Forms.ComboBox
$script:PortBox.DropDownStyle = 'DropDownList'
$script:PortBox.Location = New-Object System.Drawing.Point(145,98)
$script:PortBox.Size = New-Object System.Drawing.Size(390,28)
$form.Controls.Add($script:PortBox)

$refresh = New-Object System.Windows.Forms.Button
$refresh.Text = 'Ports aktualisieren'
$refresh.Location = New-Object System.Drawing.Point(545,96)
$refresh.Size = New-Object System.Drawing.Size(125,30)
$refresh.Add_Click({ Refresh-Ports })
$form.Controls.Add($refresh)

$install = New-Object System.Windows.Forms.Button
$install.Text = 'AVRDUDE installieren'
$install.Location = New-Object System.Drawing.Point(20,140)
$install.Size = New-Object System.Drawing.Size(160,34)
$install.Add_Click({ Install-Avrdude })
$form.Controls.Add($install)

$test = New-Object System.Windows.Forms.Button
$test.Text = 'Verbindung testen'
$test.Location = New-Object System.Drawing.Point(190,140)
$test.Size = New-Object System.Drawing.Size(150,34)
$test.Add_Click({ [void](Test-Target) })
$form.Controls.Add($test)

$fuses = New-Object System.Windows.Forms.Button
$fuses.Text = 'Fuses auslesen'
$fuses.Location = New-Object System.Drawing.Point(350,140)
$fuses.Size = New-Object System.Drawing.Size(135,34)
$fuses.Add_Click({ Read-Fuses })
$form.Controls.Add($fuses)

$help = New-Object System.Windows.Forms.Button
$help.Text = 'Anleitung oeffnen'
$help.Location = New-Object System.Drawing.Point(495,140)
$help.Size = New-Object System.Drawing.Size(140,34)
$help.Add_Click({
    $p=Join-Path $Root 'README_DIAMEX_Trainer.md'
    if(Test-Path $p){ Start-Process notepad.exe $p }
})
$form.Controls.Add($help)

$sep = New-Object System.Windows.Forms.Label
$sep.Text = 'Gewuenschte Taster-ID:'
$sep.Font = New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold)
$sep.AutoSize = $true
$sep.Location = New-Object System.Drawing.Point(20,198)
$form.Controls.Add($sep)

for ($i=1; $i -le 5; $i++) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = "Buzzer $i programmieren"
    $b.Size = New-Object System.Drawing.Size(135,55)
    $b.Location = New-Object System.Drawing.Point((20 + (($i-1)*145)),228)
    $id = $i
    $b.Add_Click({ param($sender,$e) Program-Buzzer ([int]$sender.Tag) })
    $b.Tag = $id
    $form.Controls.Add($b)
}

$profileLabel = New-Object System.Windows.Forms.Label
$profileLabel.Text = 'Firmware:'
$profileLabel.Location = New-Object System.Drawing.Point(20,294)
$profileLabel.AutoSize = $true
$form.Controls.Add($profileLabel)
$script:FirmwareProfile = New-Object System.Windows.Forms.ComboBox
$script:FirmwareProfile.DropDownStyle = 'DropDownList'
$script:FirmwareProfile.Location = New-Object System.Drawing.Point(100,290)
$script:FirmwareProfile.Size = New-Object System.Drawing.Size(345,28)
[void]$script:FirmwareProfile.Items.Add('V1 - bisherige Firmware (IDs 1-5)')
[void]$script:FirmwareProfile.Items.Add('V2 - Zeitstempel / Kollisionsminderung')
$script:FirmwareProfile.SelectedIndex = 1
$form.Controls.Add($script:FirmwareProfile)
$script:ReceiverReady = New-Object System.Windows.Forms.CheckBox
$script:ReceiverReady.Text = "Pi-Empfaenger diamex-5`r`nvorher installiert"
$script:ReceiverReady.Location = New-Object System.Drawing.Point(460,286)
$script:ReceiverReady.Size = New-Object System.Drawing.Size(270,48)
$form.Controls.Add($script:ReceiverReady)
$customLabel = New-Object System.Windows.Forms.Label
$customLabel.Text = 'Eigene ID:'
$customLabel.Location = New-Object System.Drawing.Point(20,341)
$customLabel.AutoSize = $true
$form.Controls.Add($customLabel)
$script:CustomId = New-Object System.Windows.Forms.NumericUpDown
$script:CustomId.Minimum = 1
$script:CustomId.Maximum = 255
$script:CustomId.Value = 6
$script:CustomId.Location = New-Object System.Drawing.Point(100,337)
$script:CustomId.Size = New-Object System.Drawing.Size(85,28)
$form.Controls.Add($script:CustomId)
$customProgram = New-Object System.Windows.Forms.Button
$customProgram.Text = 'Eigene ID programmieren'
$customProgram.Location = New-Object System.Drawing.Point(200,333)
$customProgram.Size = New-Object System.Drawing.Size(245,36)
$customProgram.Add_Click({ Program-Buzzer ([int]$script:CustomId.Value) })
$form.Controls.Add($customProgram)

$script:StatusLabel = New-Object System.Windows.Forms.Label
$script:StatusLabel.Text = 'Status: bereit'
$script:StatusLabel.Font = New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
$script:StatusLabel.AutoSize = $true
$script:StatusLabel.Location = New-Object System.Drawing.Point(20,400)
$form.Controls.Add($script:StatusLabel)

$logLabel = New-Object System.Windows.Forms.Label
$logLabel.Text = 'Protokoll:'
$logLabel.Location = New-Object System.Drawing.Point(20,430)
$logLabel.AutoSize = $true
$form.Controls.Add($logLabel)

$script:LogBox = New-Object System.Windows.Forms.TextBox
$script:LogBox.Multiline = $true
$script:LogBox.ScrollBars = 'Vertical'
$script:LogBox.ReadOnly = $true
$script:LogBox.Font = New-Object System.Drawing.Font('Consolas',9)
$script:LogBox.Location = New-Object System.Drawing.Point(20,452)
$script:LogBox.Size = New-Object System.Drawing.Size(720,245)
$script:LogBox.Anchor = 'Top,Bottom,Left,Right'
$form.Controls.Add($script:LogBox)

$foot = New-Object System.Windows.Forms.Label
$foot.Text = 'Beim Flashen den Funktaster bis zur Erfolgsmeldung eingeschaltet lassen. Niemals -F/Signaturzwang verwenden.'
$foot.AutoSize = $true
$foot.Location = New-Object System.Drawing.Point(20,710)
$foot.Anchor = 'Bottom,Left'
$form.Controls.Add($foot)

Refresh-Ports
if (Find-Avrdude) { Write-Log ('AVRDUDE gefunden: ' + (Find-Avrdude)) } else { Write-Log 'AVRDUDE noch nicht installiert. Schaltflaeche oben verwenden.' }
Write-Log 'Programmer bereit. Zuerst COM-Port waehlen und Verbindung testen.'
[void]$form.ShowDialog()
