@echo off
setlocal
cd /d "%~dp0"
title Wasserfreunde Dalum - Funktaster Programmer
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Funktaster_Programmer.ps1"
if errorlevel 1 (
  echo.
  echo Der Programmer konnte nicht gestartet werden.
  echo Siehe README_DIAMEX_Trainer.md
  pause
)
