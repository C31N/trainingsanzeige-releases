/*
 * Funktaster-Firmware fuer ATtiny13A + STX882
 *
 * Hardwarebasis: Lochrasterplan V3
 *   - STX882 DATA an ATtiny13A PB3 / Pin 2
 *   - PB0/PB1/PB2 bleiben fuer ISP (MOSI/MISO/SCK)
 *   - Versorgung 3,3 V
 *
 * Build-Beispiel:
 *   avr-gcc -mmcu=attiny13a -DF_CPU=9600000UL -DBUTTON_ID=1 \
 *       -Os -std=gnu11 -Wall -Wextra -ffunction-sections -fdata-sections \
 *       -Wl,--gc-sections -o buzzer1.elf funktaster.c
 *   avr-objcopy -O ihex -R .eeprom buzzer1.elf buzzer1.hex
 *
 * BUTTON_ID: 1..5
 */

#ifndef F_CPU
#define F_CPU 9600000UL
#endif

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include <stdint.h>

#ifndef BUTTON_ID
#define BUTTON_ID 1
#endif

#if (BUTTON_ID < 1) || (BUTTON_ID > 5)
#error "BUTTON_ID muss zwischen 1 und 5 liegen."
#endif

#define TX_BIT              PB3

#define PREAMBLE_CYCLES     8
#define REPEAT_COUNT        5
#define INTERFRAME_MS       3
#define POWER_SETTLE_MS     15

/* Funktelegramm:
 * Byte 0: 0xD3
 * Byte 1: 0x6C
 * Byte 2: BUTTON_ID (1..5)
 * Byte 3: CRC-8, Polynom 0x07, Startwert 0x00
 *
 * Bitcodierung, MSB zuerst, 300 us pro Bit:
 *   0 = HIGH 100 us + LOW 200 us
 *   1 = HIGH 200 us + LOW 100 us
 *
 * Praeambel:
 *   8 x (HIGH 150 us + LOW 150 us)
 *
 * Sync:
 *   HIGH 300 us + LOW 900 us
 */

static inline void tx_low(void)
{
    PORTB &= (uint8_t)~_BV(TX_BIT);
}

static inline void tx_high(void)
{
    PORTB |= _BV(TX_BIT);
}

static void delay_ms_u8(uint8_t ms)
{
    while (ms--) {
        _delay_ms(1);
    }
}

static void send_bit(uint8_t one)
{
    if (one) {
        tx_high();
        _delay_us(200);
        tx_low();
        _delay_us(100);
    } else {
        tx_high();
        _delay_us(100);
        tx_low();
        _delay_us(200);
    }
}

static void send_byte(uint8_t value)
{
    for (uint8_t i = 0; i < 8; i++) {
        send_bit(value & 0x80);
        value <<= 1;
    }
}

static uint8_t crc8_add(uint8_t crc, uint8_t data)
{
    crc ^= data;

    for (uint8_t i = 0; i < 8; i++) {
        if (crc & 0x80) {
            crc = (uint8_t)((crc << 1) ^ 0x07);
        } else {
            crc <<= 1;
        }
    }

    return crc;
}

static uint8_t frame_crc(void)
{
    uint8_t crc = 0x00;

    crc = crc8_add(crc, 0xD3);
    crc = crc8_add(crc, 0x6C);
    crc = crc8_add(crc, (uint8_t)BUTTON_ID);

    return crc;
}

static void send_preamble_and_sync(void)
{
    for (uint8_t i = 0; i < PREAMBLE_CYCLES; i++) {
        tx_high();
        _delay_us(150);
        tx_low();
        _delay_us(150);
    }

    tx_high();
    _delay_us(300);
    tx_low();
    _delay_us(900);
}

static void send_frame(void)
{
    const uint8_t crc = frame_crc();

    send_preamble_and_sync();

    send_byte(0xD3);
    send_byte(0x6C);
    send_byte((uint8_t)BUTTON_ID);
    send_byte(crc);

    tx_low();
}

static void go_to_sleep_forever(void)
{
    /* Sender sicher aus. */
    tx_low();

    /* Nicht benoetigte Analog-Bloecke abschalten. */
    ADCSRA &= (uint8_t)~_BV(ADEN);
    ACSR |= _BV(ACD);

    set_sleep_mode(SLEEP_MODE_PWR_DOWN);
    sleep_enable();

    /*
     * Keine Interruptquelle aktivieren.
     * Der Controller soll nur durch Reset / erneutes Einschalten neu starten.
     */
    cli();

    for (;;) {
        sleep_cpu();
    }
}

int main(void)
{
    /*
     * Watchdog sicher deaktivieren.
     * WDTON-Fuse bleibt unprogrammiert.
     */
    cli();
    MCUSR = 0;
    wdt_disable();

    /*
     * PB3 sofort als LOW-Ausgang konfigurieren.
     * Der externe 10-kOhm-Pulldown am STX882 haelt DATA bereits
     * waehrend des Resets auf LOW.
     */
    tx_low();
    DDRB |= _BV(TX_BIT);

    /*
     * Kurze Zusatzwartezeit nach dem Hardware-Start.
     * Zusammen mit SUT=4 ms reduziert das die Gefahr,
     * dass Kontaktprellen mehrere Sendungen erzeugt.
     */
    delay_ms_u8(POWER_SETTLE_MS);

    /*
     * Ein begrenzter Burst pro Einschaltvorgang.
     * Danach wird nie wieder gesendet, solange der Taster gehalten wird.
     */
    for (uint8_t n = 0; n < REPEAT_COUNT; n++) {
        send_frame();

        if (n + 1 < REPEAT_COUNT) {
            delay_ms_u8(INTERFRAME_MS);
        }
    }

    go_to_sleep_forever();
}
